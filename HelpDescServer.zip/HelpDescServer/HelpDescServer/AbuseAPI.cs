﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Text.RegularExpressions;
using System.IO;
using System.Security.Cryptography;
using System.Net.WebSockets;
using System.Web;

namespace HelpDescServer
{
    class AbuseAPI
    {
        //Unavailable
        public class IPClient
        {
            public bool Block = false;
            public DateTime Blocktime;
            public DateTime lasttime;
            public ulong entercount;
            public Dictionary<string, object> param = new Dictionary<string, object>();
            public DateTime time = DateTime.Now;
            public IPAddress ip;
            public static List<IPClient> iplist = new List<IPClient>();
            public static decimal MidPerMin = 0;
            public IPClient(IPAddress ip)
            {
                this.ip = ip;
            }
            public static void CheckOld()
            {
                lock (iplist)
                {
                    for (int i = 0; i < iplist.Count; i++)
                    {
                        if (DateTime.Now.Subtract(iplist[i].time).TotalHours > 24 * 7)
                        {
                            iplist.RemoveAt(i);
                            i--;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
            public static bool Add(IPAddress ip, DateTime date)
            {
                lock (iplist)
                {
                    var ipinfo = GetByIP(ip);
                    if (ipinfo == null)
                    {
                        IPClient newip = new IPClient(ip);
                        iplist.Add(newip);

                        var outer = Task.Factory.StartNew(() =>
                        {
                            decimal ot = AbuseAPI.GetCh(AbuseAPI.CheckIP(newip.ip.ToString()));
                            lock (Console.Out)
                            {
                                Console.BackgroundColor = ConsoleColor.Green;
                                Console.ForegroundColor = ConsoleColor.Black;
                                Console.WriteLine(newip.ip.ToString() + " Abuse IP rat - " + Math.Round(ot, 1));
                                Console.BackgroundColor = ConsoleColor.Black;
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            if (ot >= 0.5m)
                            {
                                newip.Block = true;
                                newip.Blocktime = DateTime.Now;
                                //Server.blacklist.Add(newip.ip);
                                lock (Console.Out)
                                {
                                    Console.BackgroundColor = ConsoleColor.Red;
                                    Console.ForegroundColor = ConsoleColor.Black;
                                    Console.WriteLine(newip.ip.ToString() + " - added to Blacklist from abuse API");
                                    Console.BackgroundColor = ConsoleColor.Black;
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                /*a: try
                                    {
                                        StreamWriter wr = new StreamWriter(Environment.CurrentDirectory + "\\BlackList.txt");
                                        for (int i = 0; i < lastconnects.Count; i++)
                                        {
                                            wr.WriteLine(lastconnects[i].ip.ToString());
                                            wr.WriteLine(Convert.ToInt32(lastconnects[i].Block).ToString());
                                            wr.WriteLine(lastconnects[i].time.ToString());
                                            if (lastconnects[i].Blocktime != null)
                                                wr.WriteLine(lastconnects[i].Blocktime.ToString());
                                            else wr.WriteLine();
                                        }
                                        wr.Close();
                                    }
                                    catch (IOException e)
                                    {
                                        System.Threading.Thread.Sleep(1000);
                                        goto a;
                                    }
                                    catch (Exception e)
                                    {
                                        Console.BackgroundColor = ConsoleColor.Red;
                                        Console.ForegroundColor = ConsoleColor.Black;
                                        Console.WriteLine("Error!!!\r\n" + e.Data);
                                        Console.BackgroundColor = ConsoleColor.Black;
                                        Console.ForegroundColor = ConsoleColor.White;
                                    }*/
                            }
                        });
                        return true;
                    }
                    else
                    {
                        return !ipinfo.Block;
                    }
                }
            }
            static bool CheckNew(IPAddress ip)
            {
                lock (iplist)
                {
                    for (int i = 0; i < iplist.Count; i++)
                    {
                        if (ip.ToString() == iplist[i].ip.ToString())
                            return false;
                    }
                }
                return true;
            }
            public static void ReadAll()
            {
                try
                {
                    StreamReader wr = new StreamReader(Environment.CurrentDirectory + "BlackList.txt");
                    string[] param = wr.ReadToEnd().Split(new String[] { "<>" }, StringSplitOptions.None);
                    for (int i = 0; i < param.Length; i++)
                    {
                        string[] args = param[i].Split(new String[] { "\r\n" }, StringSplitOptions.None);
                        if (args.Length >= 1)
                        {
                            try
                            {
                                IPAddress add = IPAddress.Parse(args[0]);
                                DateTime time = DateTime.Parse(args[2]);
                                bool block = Convert.ToBoolean(int.Parse(args[1]));
                                DateTime blocktime = DateTime.Now; ;
                                if (args[3] != " ")
                                    blocktime = DateTime.Parse(args[3]);
                                IPClient ncl = new IPClient(add);
                                ncl.Block = block;
                                ncl.Blocktime = blocktime;
                                AbuseAPI.IPClient.iplist.Add(ncl);
                            }
                            catch (Exception ex)
                            {
                                Console.BackgroundColor = ConsoleColor.Red;
                                Console.ForegroundColor = ConsoleColor.Black;
                                Console.WriteLine("Error!!!\r\n" + ex.Data);
                                Console.BackgroundColor = ConsoleColor.Black;
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                        }
                    }
                    wr.Close();
                }
                catch (Exception e)
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine("Error2!!!\r\n" + e.Data);
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            public static IPClient GetByIP(IPAddress ip)
            {
                lock (iplist)
                {
                    for (int i = 0; i < iplist.Count; i++)
                    {
                        if (ip.ToString() == iplist[i].ip.ToString())
                            return iplist[i];
                    }
                }
                return null;
            }
            public bool TryGetParam(string param, out string res)
            {
                object ot;
                try
                {
                    if (this.param.TryGetValue(param, out ot))
                    {
                        res = Convert.ToString(ot);
                        return true;
                    }
                }
                catch (Exception ex)
                {

                }
                res = null;
                return false;
            }
            public bool TryGetParam(string param, out object res)
            {
                object ot;
                try
                {
                    if (this.param.TryGetValue(param, out ot))
                    {
                        res = ot;
                        return true;
                    }
                }
                catch (Exception ex)
                {

                }
                res = null;
                return false;
            }
            public bool TryGetParam(string param, out int res)
            {
                object ot;
                try
                {
                    if (this.param.TryGetValue(param, out ot))
                    {
                        res = Convert.ToInt32(ot);
                        return true;
                    }
                }
                catch (Exception ex)
                {

                }
                res = 0;
                return false;
            }
            public bool TryGetParam(string param, out ulong res)
            {
                object ot;
                try
                {
                    if (this.param.TryGetValue(param, out ot))
                    {
                        res = Convert.ToUInt64(ot);
                        return true;
                    }
                }
                catch (Exception ex)
                {

                }
                res = 0;
                return false;
            }
            public bool TryGetParam(string param, out bool res)
            {
                object ot;
                try
                {
                    if (this.param.TryGetValue(param, out ot))
                    {
                        res = Convert.ToBoolean(ot);
                        return true;
                    }
                }
                catch (Exception ex)
                {

                }
                res = false;
                return false;
            }
            public bool TryGetParam(string param, out DateTime res)
            {
                object ot;
                try
                {
                    if (this.param.TryGetValue(param, out ot))
                    {
                        res = DateTime.Parse(ot.ToString());
                        return true;
                    }
                }
                catch (Exception ex)
                {

                }
                res = DateTime.MinValue;
                return false;
            }
        }

        //https://www.abuseipdb.com/check/[IP]/json?key=[API_KEY]&days=[DAYS]
        public static string APIkey = "x249dieAwummv9bgpN7P7fzp7R2Ai4NG65hHGTih";
        public static int days = 30;
        static string[] categories = new string[] {
        "Fraud Orders",
        "DDoS Attack",
        "FTP Brute-Force",
        "Ping of Death",
        "Phishing",
        "Fraud VoIP",
        "Open Proxy",
        "Web Spam",
        "Email Spam",
        "Blog Spam",
        "VPN IP",
        "Port Scan",
        "Hacking",
        "SQL Injection",
        "Spoofing",
        "Brute-Force",
        "Bad Web Bot",
        "Exploited Host",
        "Web App Attack",
        "SSH",
        "IoT Targeted"
        };
        static string[] critical = new string[] { "4", "6", "10", "11", "12", "14", "15", "16", "17", "18", "21" };
        public static Dictionary<string, uint> CheckIP(string ip)
        {
            string ot = ServerMain.Get_Def("https://www.abuseipdb.com/check/" + ip + "/json?key=" + APIkey + "&days=" + days);
            Dictionary<string, uint> bads = new Dictionary<string, uint>();
            string[] param = ot.Split(new string[] { "},{", "[{", "}]" }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < param.Length; i++)
            {
                string[] args = param[i].Split(new string[] { "\",\"", ",\"" }, StringSplitOptions.RemoveEmptyEntries);
                for (int g = 0; g < args.Length; g++)
                {
                    args[g] = args[g].Replace("\":", "=").Replace("\"", "");
                }
                for (int g = 0; g < args.Length; g++)
                {
                    string[] spl = args[g].Split('=');
                    if (spl.Length == 2)
                    {
                        if (spl[0] == "category")
                        {
                            string[] cats = spl[1].Split(new string[] { "[", ",", "]" }, StringSplitOptions.RemoveEmptyEntries);
                            for (int h = 0; h < cats.Length; h++)
                            {
                                if (bads.ContainsKey(cats[h])) bads[cats[h]]++; else bads.Add(cats[h], 1);
                            }
                        }
                    }
                    else
                    {

                    }
                }
            }
            return bads;
        }
        public static decimal GetCh(Dictionary<string, uint> dic)
        {
            decimal war = 0;
            foreach (string key in dic.Keys)
            {
                if (IndexOfArray(critical, key))
                    war += dic[key];
            }
            int line = 5;
            return war / line;
        }

        static bool IndexOfArray(string[] arr, string par)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (par == arr[i])
                    return true;
            }
            return false;
        }
    }
}
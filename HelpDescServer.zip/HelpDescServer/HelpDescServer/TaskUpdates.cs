﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class TaskUpdates
    {
        public int Id { get; set; }
        public DateTime TimeStamp { get => timeStamp; set => timeStamp = value; }

        /// <summary>
        /// Данная строка имеет особые варианты форматирования:
        /// Выделение цветом:<code>"Следующее Red^слово^ красого цвета"</code>
        /// Переменная вставка переменной:<code>"Дата регистрации:&User.RegDate&"</code>
        /// Список переменных:
        /// User.FullName - ФИО клиента
        /// User.FName
        /// User.LName
        /// User.Patronymic
        /// User.RegDate
        /// Date
        /// Time
        /// DateTime
        /// </summary>
        public string UpdateString { get; set; } = "";

        private DateTime timeStamp = DateTime.Now;

        static string[] Variables = new string[] {
            "User.FullName",
            "User.FName",
            "User.LName",
            "User.Patronymic",
            "User.RegDate",
            "Date",
            "Time",
            "DateTime"};

        public TaskUpdates(string updateString)
        {
            UpdateString = updateString;
            TimeStamp = DateTime.Now;
        }

        public string[][] GetLine()
        {
            string WithVars = SetVariables();
            List<string[]> result = new List<string[]>();
            int offset = 0;
            for (; true;)
            {
                int pos1 = WithVars.IndexOf('^', offset);
                int pos2 = -1;
                if (pos1 >= 0)
                {
                    int pospref = UpdateString.LastIndexOf(' ', pos1);
                    if (pospref == -1)
                    {
                        pospref = pos1 - offset;
                    }
                    else
                    {
                        pospref = pos1 - pospref;
                    }
                    string pref = UpdateString.Substring(pos1 - pospref, pospref);
                    Color col = Color.FromName(pref);
                    pos2 = WithVars.IndexOf('^', pos1 + 1);
                    offset = pos2 != -1 ? pos2 + 1 : pos1 + 1;
                    if (col != null & pos2 != -1)
                    {
                        string var = WithVars.Substring(pos1 + 1, pos2 - pos1 - 1);
                        string leftside = WithVars.Substring(0, pos1 - pospref);
                        string rightside = WithVars.Substring(pos2 + 1);
                        if (leftside.Length > 0)
                        {
                            result.Add(new string[] { leftside });
                        }
                        if (var.Length > 0)
                        {
                            result.Add(new string[] { var, pref });
                        }
                        offset = 0;
                        WithVars = rightside;
                    }
                    else
                    {

                    }
                }
                else
                {
                    if (WithVars.Length > 0)
                    {
                        result.Add(new string[] { WithVars });
                    }
                    return result.ToArray();
                }
            }
            return result.ToArray();
        }

        string SetVariables()
        {
            string res = UpdateString;
            int offset = 0;
            for (; true;)
            {
                int pos1 = res.IndexOf('&', offset);
                int pos2 = -1;
                if (pos1 >= 0)
                {
                    pos2 = res.IndexOf('&', pos1 + 1);
                    if (pos2 == -1)
                    {
                        return res;
                    }
                    string var = res.Substring(pos1 + 1, pos2 - pos1 - 1);
                    int num = Variables.ToList().IndexOf(var);
                    if (num >= 0)
                    {
                        res = res.Replace("&" + var + "&", GetValue(var));
                    }
                    else
                    {

                    }
                    offset = pos2;
                }
                else
                {
                    return res;
                }
            }
            return res;
        }

        string GetValue(string name)
        {
            if (name == "DateTime")
                return TimeStamp.ToShortDateString() + " " + TimeStamp.ToShortTimeString();
            else if (name == "Date")
                return TimeStamp.ToShortDateString();
            else if (name == "Time")
                return TimeStamp.ToShortTimeString();
            else
                return "";
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class TaskStage
    {
        public static List<TaskStage> TaskStages = new List<TaskStage>();
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";

        public double SLAminute { get; set; }
        public virtual List<Role> Roles { get; set; } = new List<Role>();
        public bool AutoPick { get => autoPick; set => autoPick = value; }
        public bool Deleted { get => deleted; set => deleted = value; }

        private bool deleted = false;
        private bool autoPick = false;

        public TaskStage()
        {
            Id = getId();
            TaskStages.Add(this);
        }
        public int getId()
        {
            return TaskStages.Count > 0 ? TaskStages[TaskStages.Count - 1].Id + 1 : 0;
        }
        public override string ToString()
        {
            return Name ?? "Без имени";
        }

        public User[] GetUsersToStage(CodeFirstContext context)
        {
            List<User> result = new List<User>();
            lock (Roles)
            {
                foreach (User user in User.Users)
                {
                    bool CanToAll = true;
                    for (int i = 0; i < Roles.Count; i++)
                    {
                        if (!user.CanDoRole(Roles[i]))
                        {
                            CanToAll = false;
                            break;
                        }
                    }
                    if (CanToAll)
                        result.Add(user);
                }
            }
            return result.ToArray();
        }

        public static void Creation(CodeFirstContext context)
        {
            TaskStage taskStage = new TaskStage()
            {
                Name = "Премодерация",
                Description = "На этот этап будут приглашены администраторы для выставления приоритетности задачи",
                SLAminute = 60,
                AutoPick = true,
                Roles = new List<Role>()
            };
            taskStage.Roles.Add(Role.GetByName(context, "Priority Manager"));
            //context.TaskStages.Add(taskStage);

            taskStage = new TaskStage()
            {
                Name = "Постмодерация",
                Description = "На этот этап будут приглашены администраторы для проверки выполненной задачи",
                SLAminute = 60,
                AutoPick = true,
                Roles = new List<Role>()
            };
            taskStage.Roles.Add(Role.GetByName(context, "Priority Manager"));
            //context.TaskStages.Add(taskStage);

            taskStage = new TaskStage()
            {
                Name = "Руководитель",
                Description = "На этот этап будут приглашены руководители для согласование важной задачи",
                SLAminute = 120,
                Roles = new List<Role>()
            };
            taskStage.Roles.Add(Role.GetByName(context, "Руководитель"));
            //context.TaskStages.Add(taskStage);

            taskStage = new TaskStage()
            {
                Name = "Бухгалтерия",
                Description = "Этап для задач связанных с финансовыми операциями",
                SLAminute = 180,
                Roles = new List<Role>()
            };
            taskStage.Roles.Add(Role.GetByName(context, "Бухгалтерия"));
            //context.TaskStages.Add(taskStage);

            taskStage = new TaskStage()
            {
                Name = "Специалист",
                Description = "Этап на котором специалист вносит отметку о проделанной работе",
                SLAminute = 240,
                AutoPick = true,
                Roles = new List<Role>()
            };
            taskStage.Roles.Add(Role.GetByName(context, "Специалист"));
            //context.TaskStages.Add(taskStage);
        }

        public static TaskStage GetByName(CodeFirstContext context, string name, bool withdel = false)
        {
            foreach (TaskStage taskStage in TaskStages)
            {
                if (!taskStage.Deleted | withdel)
                    if (taskStage.Name.ToLower() == name.ToLower())
                        return taskStage;
            }
            return null;
        }

        public Permision[] GetAllPermisions()
        {
            List<Permision> result = new List<Permision>();
            foreach (Role role in Roles)
                result.AddRange(role.GetAllPermisions());
            return result.ToArray();
        }

        public Role[] GetAllRoles()
        {
            List<Role> result = new List<Role>();
            foreach (Role role in Roles)
                result.Add(role);
            return result.ToArray();
        }

        public User GetUserWithLowestSLAsum()
        {
            var users = GetUsersToStage(null);
            if (users.Count() != 0)
            {
                for (int i = 0; i < users.Length; i++)
                {
                    users[i].SLALast = users[i].GetSLAsum();
                }
                users = users.OrderBy(x => x.SLALast).ToArray();
                return users.ToArray()[0];
            }
            else
            {
                return null;
            }
        }

        public static TaskStage[] SearchByText(CodeFirstContext context, string text, bool withdel = false)
        {
            var cachres = SearchCach.GetRes(text, typeof(TaskStage), new TimeSpan(0, 0, 30));
            if (cachres == null)
            {
                List<Result> results = new List<Result>();
                List<TaskStage> stages = new List<TaskStage>();
                foreach (TaskStage stage in TaskStage.TaskStages)
                {
                    if (!stage.Deleted | withdel)
                    {
                        if (text != "")
                        {
                            string a = stage.Id + "/" + stage.Name + "/" + stage.Description + "/" + stage.Roles.ToArray().ArrayToString('/') + "/" + stage.GetAllPermisions().ArrayToString('/');
                            double res = a.CompareString(text);
                            if (res > 0)
                            {
                                results.Add(new Result() { item = stage, rank = res });
                            }
                        }
                        else
                        {
                            stages.Add(stage);
                        }
                    }
                }
                if (stages.Count == 0)
                {
                    if (results.Count > 0)
                        results = results.OrderByDescending(x => x.rank).ToList();
                    for (int i = 0; i < results.Count; i++)
                    {
                        stages.Add(results[i].item as TaskStage);
                    }
                }
                SearchCach.SetRes(text, typeof(TaskStage), stages.ToArray());
                return stages.ToArray();
            }
            else
            {
                return (cachres as TaskStage[]);
            }
        }

        public static TaskStage GetById(string id, bool withdel = false)
        {
            for (int i = 0; i < TaskStages.Count; i++)
            {
                if (TaskStages[i].Id.ToString() == id)
                {
                    return TaskStages[i];
                }
            }
            return null;
        }
    }
}
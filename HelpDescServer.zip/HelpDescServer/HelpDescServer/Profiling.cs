﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace HelpDescServer
{
    class Profiling
    {
        public static decimal Period = 150;
        public static List<ProfilingCPU> cpuload = new List<ProfilingCPU>();
        public class ProfilingCPU
        {
            public Stopwatch sw;
            public Stopwatch swall;
            public int StTime = Environment.TickCount;
            public long dif = 0;
            public bool last = false;
        }
        public static decimal GetAllLoad()
        {
            decimal time = 0;
            lock (cpuload)
            {
                for (int i = 0; i < cpuload.Count; i++)
                {
                    long dift = (cpuload[i].swall.ElapsedMilliseconds - cpuload[i].sw.ElapsedMilliseconds - cpuload[i].dif);
                    time += (Period - dift) / Period;
                    /*if (cpuload[i].swall.ElapsedMilliseconds < Period)
                    {
                        time += cpuload[i].sw.ElapsedMilliseconds / cpuload[i].swall.ElapsedMilliseconds / Period;//bad
                    }
                    else if (cpuload[i].sw.ElapsedMilliseconds < Period)
                    {
                        time += (cpuload[i].swall.ElapsedMilliseconds - dift) / cpuload[i].swall.ElapsedMilliseconds;
                    }
                    else
                    {
                        time += (Period - dift) / Period;
                    }*/
                    cpuload[i].dif = cpuload[i].swall.ElapsedMilliseconds - cpuload[i].sw.ElapsedMilliseconds;
                }
                time /= Environment.ProcessorCount;
            }
            return time;
        }
        public static void CleaN()
        {
            lock (cpuload)
            {
                for (int i = 0; i < cpuload.Count; i++)
                {
                    if (cpuload[i].last)
                    {
                        cpuload.RemoveAt(i);
                        i--;
                    }
                }
            }
        }
        public static decimal GetReqPerSec()
        {
            decimal time = 0;
            lock (cpuload)
            {
                for (int i = 0; i < cpuload.Count; i++)
                {
                    if (Environment.TickCount-cpuload[i].StTime < 1000)
                    {
                        time ++;
                    }
                }
            }
            return time;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class TaskType
    {
        public static List<TaskType> TaskTypes = new List<TaskType>();
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public virtual List<TaskStage> Stages { get; set; } = new List<TaskStage>();
        public bool Deleted { get => deleted; set => deleted = value; }
        public bool isDefault { get; set; } = false;

        private bool deleted = false;

        public TaskType()
        {
            Id = getId();
            TaskTypes.Add(this);
        }
        public int getId()
        {
            return TaskTypes.Count > 0 ? TaskTypes[TaskTypes.Count - 1].Id + 1 : 0;
        }
        public override string ToString()
        {
            return Name ?? "Без имени";
        }
        public static void Creation(CodeFirstContext context)
        {
            TaskType taskType = new TaskType()
            {
                Stages = new List<TaskStage>(),
                Name = "Неизвестная проблема",
                Description = "Задача заводиться в случае возникновения проблемы, которая не обозначена в списке",
            };
            taskType.Stages.Add(TaskStage.GetByName(context, "Премодерация"));
            //context.TaskTypes.Add(taskType);


            taskType = new TaskType()
            {
                Stages = new List<TaskStage>(),
                Name = "Поломка бытовой техники",
                Description = "Задача заводиться в случае возникновения поломок с бытовой техникой"
            };
            taskType.Stages.Add(TaskStage.GetByName(context, "Премодерация"));
            taskType.Stages.Add(TaskStage.GetByName(context, "Специалист"));
            //context.TaskTypes.Add(taskType);

            taskType = new TaskType()
            {
                Stages = new List<TaskStage>(),
                Name = "Установка платного ПО",
                Description = "Задача заводиться в случае необходимости установки платного ПО"
            };
            taskType.Stages.Add(TaskStage.GetByName(context, "Премодерация"));
            taskType.Stages.Add(TaskStage.GetByName(context, "Руководитель"));
            taskType.Stages.Add(TaskStage.GetByName(context, "Бухгалтерия"));
            taskType.Stages.Add(TaskStage.GetByName(context, "Специалист"));
            //context.TaskTypes.Add(taskType);
            //context.SaveChanges();

            taskType = new TaskType()
            {
                Stages = new List<TaskStage>(),
                Name = "Не работает программа / Сбой ПО",
                Description = "Задача заводиться в случае неисправности ПО"
            };
            taskType.Stages.Add(TaskStage.GetByName(context, "Премодерация"));
            taskType.Stages.Add(TaskStage.GetByName(context, "Специалист"));
            //context.TaskTypes.Add(taskType);
            //context.SaveChanges();

            taskType = new TaskType()
            {
                Stages = new List<TaskStage>(),
                Name = "Разблокировка",
                Description = "Задача заводиться в случае блокировки пользователя или потери пароля"
            };
            taskType.Stages.Add(TaskStage.GetByName(context, "Руководитель"));
            taskType.Stages.Add(TaskStage.GetByName(context, "Премодерация"));
            taskType.Stages.Add(TaskStage.GetByName(context, "Специалист"));
            taskType.Stages.Add(TaskStage.GetByName(context, "Постмодерация"));
            //context.TaskTypes.Add(taskType);
            //context.SaveChanges();

        }

        public static TaskType GetDefault()
        {
            foreach (TaskType taskType in TaskTypes)
            {
                if (taskType.isDefault & !taskType.Deleted)
                    return taskType;
            }
            return TaskTypes.Count > 0 ? TaskTypes[0] : null;
        }

        public static TaskType GetByName(CodeFirstContext context, string name, bool withdel = false)
        {
            foreach (TaskType taskType in TaskTypes)
            {
                if (!taskType.Deleted | withdel)
                    if (taskType.Name.ToLower() == name.ToLower())
                        return taskType;
            }
            return null;
        }

        public static TaskType[] GetAll(CodeFirstContext context, bool withdel = false)
        {
            List<TaskType> res = new List<TaskType>();
            foreach (TaskType taskType in TaskTypes)
            {
                if (!taskType.Deleted | withdel)
                    res.Add(taskType);
            }
            return res.ToArray();
        }

        public static TaskType[] SearchByText(CodeFirstContext context, string text, bool withdel)
        {
            var cachres = SearchCach.GetRes(text, typeof(TaskType), new TimeSpan(0, 0, 30));
            if (cachres == null)
            {
                List<Result> results = new List<Result>();
                List<TaskType> stages = new List<TaskType>();
                foreach (TaskType stage in TaskType.TaskTypes)
                {
                    if (!stage.Deleted | withdel)
                    {
                        if (text != "")
                        {
                            string a = stage.Id + "/" + stage.Name + "/" + stage.Description + "/" + stage.Stages.ToArray().ArrayToString('/');
                            double res = a.CompareString(text);
                            if (res > 0)
                            {
                                results.Add(new Result() { item = stage, rank = res });
                            }
                        }
                        else
                        {
                            stages.Add(stage);
                        }
                    }
                }
                if (stages.Count == 0)
                {
                    if (results.Count > 0)
                        results = results.OrderByDescending(x => x.rank).ToList();
                    for (int i = 0; i < results.Count; i++)
                    {
                        stages.Add(results[i].item as TaskType);
                    }
                }
                SearchCach.SetRes(text, typeof(TaskType), stages.ToArray());
                return stages.ToArray();
            }
            else
            {
                return (cachres as TaskType[]);
            }
        }

        public static TaskType GetById(string id)
        {
            foreach (TaskType taskType in TaskTypes)
            {
                if (taskType.Id.ToString() == id)
                    return taskType;
            }
            return null;
        }
    }
}
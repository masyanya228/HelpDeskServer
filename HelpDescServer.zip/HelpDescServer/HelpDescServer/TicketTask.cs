﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class TicketTask
    {
        public static List<TicketTask> TicketTasks = new List<TicketTask>();
        [Key]
        public int Id { get; set; }
        public User Sender { get; set; }
        public TaskType Type { get; set; }
        public DateTime ReqDate { get => reqDate; set => reqDate = value; }
        public double Priority { get; set; }
        public virtual List<TaskStage> Stages { get => stages; set => stages = value; }
        public virtual List<Agreement> Agreements { get => agreements; set => agreements = value; }
        public virtual List<TaskUpdates> TaskUpdates { get => taskUpdates; set => taskUpdates = value; }
        public bool Deleted { get => deleted; set => deleted = value; }
        public bool Closed { get => closed; set => closed = value; }
        public string Comments { get => comments; set => comments = value; }

        private string comments = "";
        private List<TaskStage> stages = new List<TaskStage>();
        private List<Agreement> agreements = new List<Agreement>();
        private List<TaskUpdates> taskUpdates = new List<TaskUpdates>();
        private bool deleted = false;
        private bool closed = false;
        private DateTime reqDate = DateTime.Now;

        public TicketTask(User sender, TaskType type, string description = "")
        {
            Id = getId();
            Sender = sender;
            Type = type;
            if (Type == null)
            {
                Type = TaskType.GetDefault();
            }
            Comments += description + "\r\n";
            ReqDate = DateTime.Now;

            TicketTasks.Add(this);
        }
        public int getId()
        {
            return TicketTasks.Count > 0 ? TicketTasks[TicketTasks.Count - 1].Id + 1 : 0;
        }
        public void SetStages()
        {
            if (Type != null)
            {
                lock (Stages)
                {
                    if (Stages.Count != 0)
                        return;
                    for (int i = 0; i < Type.Stages.Count; i++)
                    {
                        Stages.Add(Type.Stages[i]);
                        if (CheckSpaceToAddAgree(Type.Stages[i]))
                        {
                            var newagree = new Agreement(Type.Stages[i]);
                            Agreements.Add(newagree);
                            if (Type.Stages[i].Roles.Contains(Role.GetDefaultLeaderRole()))
                            {
                                var user = User.GetByLogin(null, Sender.LoginOfLeader ?? "", false);
                                if (user != null)
                                {
                                    newagree.Visor = user;
                                }
                                else
                                {
                                    newagree.Visor = Role.GetDefaultLeaderRole()?.GetUserWithLowestSLAsum();
                                }
                            }
                            else if (Type.Stages[i].AutoPick)
                            {
                                var user = Type.Stages[i].GetUserWithLowestSLAsum();
                                user.SLALast += Type.Stages[i].SLAminute;
                                newagree.Visor = user;
                            }
                        }
                        else
                        {

                        }
                    }
                    var agreement = GetNextAgree();
                    if (agreement != null)
                    {
                        agreement.DateOfReq = DateTime.Now;
                    }
                    else
                    {

                    }
                }
            }
        }

        /// <summary>
        /// Вычисление разницы между Не согласованными и этапами по роли
        /// </summary>
        /// <param name="taskStage"></param>
        /// <returns></returns>
        public bool CheckSpaceToAddAgree(TaskStage taskStage)
        {
            int col = 0;
            lock (Stages)
            {
                for (int i = 0; i < Stages.Count; i++)
                {
                    if (Stages[i] == taskStage)
                        col++;
                }
            }
            lock (Agreements)
            {
                for (int i = 0; i < Agreements.Count; i++)
                {
                    if (Agreements[i].TaskStage == taskStage)
                        if (!Agreements[i].Checked)
                            col--;
                }
                return (col > 0);
            }
        }

        /// <summary>
        /// Вычисление кол-ва не согласованных по роли
        /// </summary>
        /// <param name="taskStage"></param>
        /// <returns></returns>
        public bool CheckSpaceToAgree(TaskStage taskStage)
        {
            int col = 0;
            lock (Stages)
            {
                for (int i = 0; i < Stages.Count; i++)
                {
                    //if (Stages[i] == taskStage)
                        //col++;
                }
            }
            lock (Agreements)
            {
                for (int i = 0; i < Agreements.Count; i++)
                {
                    if (Agreements[i].TaskStage == taskStage)
                    {
                        col++;
                        if (Agreements[i].Checked)
                            col--;
                    }
                }
                return (col > 0);
            }
        }

        public bool CheckVisibilityForUser(User user, CodeFirstContext context)
        {
            if (user == null)
                return false;
            if (user.GetAllPermisions().ToList().IndexOf(Permision.GetByName(context, ".tickets.View")) >= 0)
            {
                return true;//супер визор
            }
            if (user == Sender)
            {
                return true;//автор задачи
            }
            var nextstage = GetNextStage();
            if (nextstage == null)
                return false;
            var nextagr = GetNextAgree();
            if (nextagr == null)
                return false;
            Role[] roles = nextstage.GetAllRoles();
            int colr = 0;
            bool allright = true;
            for (int i = 0; i < roles.Length; i++)
            {
                for (int j = 0; j < user.Roles.Count; j++)
                {
                    if (roles[i] == user.Roles[j])
                    {
                        colr++;
                        break;
                    }
                }
            }
            allright = colr == roles.Length;
            if (allright)
                if (nextagr.Visor != null)
                    if (nextagr.Visor != user)
                        return user.HavePermision(".Agreements.Visor.Edit");
                    else
                        return true;
                else
                    return true;
            else
                return false;
        }

        public TaskStage GetNextStage()
        {
            lock (Stages)
            {
                for (int i = 0; i < Stages.Count; i++)
                {
                    if (CheckSpaceToAgree(Stages[i]))
                        return Stages[i];
                }
            }
            return null;
        }

        public Agreement GetNextAgree()
        {
            TaskStage taskStage = GetNextStage();
            Agreement[] Agrees = GetAllAgree(taskStage);
            Agrees = Agrees.OrderBy(x => x.DateOfReq).ToArray();
            for (int i = 0; i < Agrees.Length; i++)
            {
                if (!Agrees[i].Checked)
                    return Agrees[i];
            }
            return null;
        }

        public Agreement[] GetAllAgree()
        {
            return Agreements.ToArray();
            /*List<Agreement> result = new List<Agreement>();
            List<Agreement> oper = new List<Agreement>();
            oper.AddRange(Agreements);
            lock (Agreements)
            {
                for (; oper.Count > 0;)
                {
                    Agreement[] agreements = oper[0].agreementsChain.ToArray();
                    for (int j = 0; j < agreements.Length; j++)
                    {
                        int pos = oper.IndexOf(agreements.ToList()[j]);
                        if (pos == -1)
                        {
                            oper.Add(agreements[j]);
                        }
                    }
                    result.Add(oper[0]);
                    oper.RemoveAt(0);
                }
            }
            return result.ToArray();*/
        }

        public Agreement[] GetAllAgree(TaskStage taskStage)
        {
            List<Agreement> result = GetAllAgree().ToList();
            for (int i = 0; i < result.Count; i++)
            {
                if (result[i].TaskStage != taskStage)
                {
                    result.RemoveAt(i);
                    i--;
                    continue;
                }
            }
            return result.ToArray();
        }

        public Role[] GetAllRoles()
        {
            List<Role> result = new List<Role>();
            foreach (TaskStage stage in Stages)
                result.AddRange(stage.GetAllRoles());
            return result.ToArray();
        }

        public bool SetAgree(User user, bool Approve, string comment)
        {
            Agreement agreement = GetNextAgree();
            if (agreement == null)
            {
                //Нет не согласованных этапов
                return false;
            }
            if (user.HavePermision(".Agreements.Visor.Edit"))
            {
                agreement.Visor = user;
                agreement.DateOfApprove = DateTime.Now;
                agreement.Aproove = Approve;
                agreement.Checked = true;
                Comments += comment + "\r\n";
                //Agreements.AddRange(agreements);
                TaskUpdates.Add(new HelpDescServer.TaskUpdates(user.ToString() + " согласовал этап " + agreement.TaskStage.Name));
                return true;
            }
            else if (agreement.Visor == null)
            {
                Role[] roles = agreement.TaskStage.GetAllRoles();
                for (int i = 0; i < roles.Length; i++)
                {
                    if (!user.CanDoRole(roles[i]))
                    {
                        return false;
                    }
                }
                agreement.Visor = user;
                agreement.DateOfApprove = DateTime.Now;
                agreement.Aproove = Approve;
                agreement.Checked = true;
                Comments += comment + "\r\n";
                TaskUpdates.Add(new HelpDescServer.TaskUpdates(user.ToString() + " согласовал этап " + agreement.TaskStage.Name));
                //Agreements.AddRange(agreements);
                return true;
            }
            else if (agreement.Visor == user)
            {
                agreement.DateOfApprove = DateTime.Now;
                agreement.Aproove = Approve;
                agreement.Checked = true;
                Comments += comment + "\r\n";
                TaskUpdates.Add(new HelpDescServer.TaskUpdates(user.ToString() + " согласовал этап " + agreement.TaskStage.Name));
                //Agreements.AddRange(agreements);
                return true;
            }
            return false;
        }

        public static bool TestCase(CodeFirstContext context)
        {
            return true;
            Random ran = new Random();
            var tt = TaskType.GetAll(context);
            for (int i = 0; i < 10; i++)
            {
                TicketTask ticketTask = new TicketTask(User.GetByLogin(context, "Mors"), tt[ran.Next(0, tt.Count() - 1)], "Что-то сломалось");
                try
                {
                    //Form1.Context.TicketTasks.Add(ticketTask);
                    ticketTask.SetStages();
                    //Form1.Context.SaveChanges();
                    int k = 0;
                }
                catch (Exception ex)
                {

                }
                /*var roles = ticketTask.GetAllRoles();
                var agrees = ticketTask.GetAllAgree();
                var nextstage = ticketTask.GetNextStage();
                var nextagree = ticketTask.GetNextAgree();
                var newagree = ticketTask.CheckSpaceToAddAgree(TaskStage.GetByName(context, "Руководитель"));
                newagree = ticketTask.CheckSpaceToAddAgree(TaskStage.GetByName(context, "Премодерация"));*/
                try
                {
                    foreach (User user in User.Users)
                    {
                        if (user.Login == "Mors")
                            continue;
                        if (ran.Next(0, 2) == 0)
                        {
                            var foruser = ticketTask.CheckVisibilityForUser(user, context);
                            if (foruser)
                            {
                                bool agreeres = ticketTask.SetAgree(user, ran.Next(0, 2) == 0 ? true : false, "All right");
                                if (agreeres)
                                {
                                    var nextstage = ticketTask.GetNextStage();
                                    var UsersToStage = nextstage?.GetUsersToStage(context);
                                }
                            }

                        }
                    }
                }
                catch (Exception ex)
                {

                }
            }
            //context.SaveChanges();
            return true;
        }

        public static TicketTask GetById(CodeFirstContext context, int ID, bool withdel = false)
        {
            foreach (TicketTask ticketTask in TicketTasks)
            {
                if (!ticketTask.Deleted | withdel)
                    if (ticketTask.Id == ID)
                        return ticketTask;
            }
            return null;
        }

        public static TicketTask[] GetAll(CodeFirstContext context, int count = -1, bool onlyopened = false, int offset = -1)
        {
            List<TicketTask> res = new List<TicketTask>();
            if (offset == -1)
            {
                if (count == -1)
                    foreach (TicketTask ticketTask in TicketTasks)
                    {
                        if (!ticketTask.Deleted & (onlyopened ? !ticketTask.Closed : true))
                            res.Add(ticketTask);
                    }
                else
                {
                    foreach (TicketTask ticketTask in TicketTasks)
                    {
                        if (!ticketTask.Deleted & (onlyopened ? !ticketTask.Closed : true))
                            res.Add(ticketTask);
                        if (res.Count >= count)
                            break;
                    }
                }
            }
            else
            {
                if (count == -1)
                    foreach (TicketTask ticketTask in TicketTasks)
                    {
                        if (!ticketTask.Deleted & (onlyopened ? !ticketTask.Closed : true))
                            if (++offset >= ticketTask.Id)
                                res.Add(ticketTask);
                    }
                else
                {
                    foreach (TicketTask ticketTask in TicketTasks)
                    {
                        if (!ticketTask.Deleted & (onlyopened ? !ticketTask.Closed : true))
                            if (++offset >= ticketTask.Id)
                                res.Add(ticketTask);
                        if (res.Count >= count)
                            break;
                    }
                }
            }
            return res.ToArray();
        }

        public static TicketTask[] SearchByText(CodeFirstContext context, string text, bool withdel=false,bool withclos=false)
        {
            var cachres = SearchCach.GetRes(text + "withdel=" + withdel.ToString(), typeof(TicketTask), new TimeSpan(0, 0, 30));
            if (cachres == null)
            {
                List<Result> results = new List<Result>();
                List<TicketTask> roles = new List<TicketTask>();
                double priorityMax = 1;
                double priorityMin = 0;
                double slaLeftMax = 0;
                double slaLeftMin = 0;
                double agreeToStageKMax = 0;
                double agreeToStageKMin = 0;
                double textCompMax = 1;
                foreach (TicketTask ticket in TicketTasks)
                {
                    if (ticket.Closed & !withclos)
                        continue;
                    if (!ticket.Deleted | withdel)
                    {
                        if (ticket.Priority < priorityMin)
                            priorityMin = ticket.Priority;
                        if (ticket.Priority > priorityMax)
                            priorityMax = ticket.Priority;

                        Agreement agreement = ticket.GetNextAgree();
                        if (agreement != null)
                        {
                            double slaK = agreement.GetLeftSla() / agreement.TaskStage.SLAminute;
                            if (slaK < slaLeftMin)
                                slaLeftMin = slaK;
                            if (slaK > agreeToStageKMax)
                                agreeToStageKMax = slaK;
                        }

                        if (ticket.Agreements.Count > 0)
                        {
                            double atsK = ticket.Agreements.Count * 1.0 / ticket.Stages.Count;
                            if (atsK < agreeToStageKMin)
                                agreeToStageKMin = atsK;
                            if (atsK > slaLeftMax)
                                slaLeftMax = atsK;
                        }

                        if (text != "")
                        {
                            string a = ticket.Id + "/" + ticket.Comments + "/" + ticket.Sender.FullName + "/" + ticket.Sender.Login + "/" + ticket.Sender.Location + "/" + ticket.Sender.LoginOfLeader + "/" + ticket.ReqDate.DateToString() + "/" + ticket.Type;
                            double res = a.CompareString(text);
                            if ((double)res > textCompMax) textCompMax = (double)res;
                            if (res > 0)
                            {
                                results.Add(new Result() { item = ticket, rank = res });
                            }
                        }
                        else
                        {
                            results.Add(new Result() { item = ticket, rank = 1 });
                        }
                    }
                }
                for (int i = 0; i < results.Count; i++)
                {
                    double rank = results[i].rank / textCompMax;
                    double prior = ((results[i].item as TicketTask).Priority - priorityMin) / (priorityMax - priorityMin);

                    Agreement agreement = (results[i].item as TicketTask).GetNextAgree();
                    double slaK = 0;
                    if (agreement != null)
                        slaK = agreement.GetLeftSla() / agreement.TaskStage.SLAminute;
                    double sla = 1 - (slaK - slaLeftMin) / (slaLeftMax - slaLeftMin);

                    double atsK = 0;
                    if ((results[i].item as TicketTask).Agreements.Count > 0)
                        atsK = (results[i].item as TicketTask).Agreements.Count * 1.0 / (results[i].item as TicketTask).Stages.Count;

                    double ats = 0;
                    if (agreeToStageKMax - agreeToStageKMin >= 0)
                        ats = (atsK - agreeToStageKMin) / (agreeToStageKMax - agreeToStageKMin);

                    results[i].rank = rank + prior + sla + ats;
                }
                if (roles.Count == 0)
                {
                    if (results.Count > 0)
                        results = results.OrderByDescending(x => x.rank).ToList();
                    for (int i = 0; i < results.Count; i++)
                    {
                        roles.Add(results[i].item as TicketTask);
                    }
                }
                SearchCach.SetRes(text + "withdel=" + withdel.ToString(), typeof(TicketTask), roles.ToArray());
                return roles.ToArray();
            }
            else
            {
                return (cachres as TicketTask[]);
            }
        }

        internal User GetLastVisorToStage()
        {
            throw new NotImplementedException();
        }
    }
}
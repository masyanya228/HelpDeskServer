﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelpDescServer
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            /*double res1 = "корабли".CompareString("кораб");
            double res2 = "коран".CompareString("кораб");*/
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    public static class Extensions
    {
        public static string DateToString(this DateTime dateTime)
        {
            return dateTime.Date.ToShortDateString() + " " + dateTime.ToShortTimeString();
        }
        public static string ArrayToString(this object[] array, char separator = ' ')
        {
            string text = "";
            for (int i = 0; i < array.Length; i++)
            {
                text += array[i].ToString() + separator;
            }
            return text.Trim(separator);
        }
        public static double CompareString(this string a, string b)
        {
            a = a.ToLower().Replace(" ", "");
            b = b.ToLower().Replace(" ", "");
            string b1 = b.Translit();
            string b2 = b.ChangeKeyBoard();
            string b3 = b2.Translit();

            b += " " + b1 + " " + b2 + " " + b3;
            double sumcomp = 0;
            string text = "";
            for (int i = 0; i < a.Length; i++)
            {
                for (int j = 0; j < b.Length; j++)
                {
                    double comp = 0;
                    for (int l = 0; i + l < a.Length & j + l < b.Length; l++)
                    {
                        if (a[i + l] == b[j + l])
                        {
                            comp++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    if (comp > 1)
                        sumcomp += comp / a.Length;
                }
            }
            return sumcomp * a.Length;
        }

        public static string Translit(this string str)
        {
            str = str.ToLower();
            string res = "";
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == 'а')
                    res += 'a';
                else if (str[i] == 'б')
                    res += 'b';
                else if (str[i] == 'в')
                    res += 'v';
                else if (str[i] == 'г')
                    res += 'g';
                else if (str[i] == 'д')
                    res += 'd';
                else if (str[i] == 'е')
                    res += 'e';
                else if (str[i] == 'ё')
                    res += 'e';
                else if (str[i] == 'ж')
                    res += 'j';
                else if (str[i] == 'з')
                    res += 'z';
                else if (str[i] == 'и')
                    res += 'i';
                else if (str[i] == 'й')
                    res += 'i';
                else if (str[i] == 'к')
                    res += 'k';
                else if (str[i] == 'л')
                    res += 'l';
                else if (str[i] == 'м')
                    res += 'm';
                else if (str[i] == 'н')
                    res += 'n';
                else if (str[i] == 'о')
                    res += 'o';
                else if (str[i] == 'п')
                    res += 'p';
                else if (str[i] == 'р')
                    res += 'r';
                else if (str[i] == 'с')
                    res += 's';
                else if (str[i] == 'т')
                    res += 't';
                else if (str[i] == 'у')
                    res += 'u';
                else if (str[i] == 'ф')
                    res += 'f';
                else if (str[i] == 'х')
                    res += 'h';

                else if (str[i] == 'ц')
                    res += "ts";
                else if (str[i] == 'ч')
                    res += "ch";
                else if (str[i] == 'ш')
                    res += "sh";
                else if (str[i] == 'щ')
                    res += "sch";
                else if (str[i] == 'ъ')
                    res += "";
                else if (str[i] == 'ы')
                    res += "i";
                else if (str[i] == 'ь')
                    res += "";
                else if (str[i] == 'э')
                    res += "e";
                else if (str[i] == 'ю')
                    res += "yu";
                else if (str[i] == 'я')
                    res += "ya";

                else if (str[i] == 'a')
                    res += 'а';
                else if (str[i] == 'b')
                    res += 'б';
                else if (str[i] == 'v')
                    res += 'в';
                else if (str[i] == 'g')
                    res += 'г';
                else if (str[i] == 'd')
                    res += 'д';
                else if (str[i] == 'e')
                    res += 'е';
                else if (str[i] == 'e')
                    res += 'ё';
                else if (str[i] == 'j')
                    res += 'ж';
                else if (str[i] == 'z')
                    res += 'з';
                else if (str[i] == 'i')
                    res += 'и';
                else if (str[i] == 'i')
                    res += 'й';
                else if (str[i] == 'k')
                    res += 'к';
                else if (str[i] == 'l')
                    res += 'л';
                else if (str[i] == 'm')
                    res += 'м';
                else if (str[i] == 'n')
                    res += 'н';
                else if (str[i] == 'o')
                    res += 'о';
                else if (str[i] == 'p')
                    res += 'п';
                else if (str[i] == 'r')
                    res += 'р';
                else if (str[i] == 's')
                    if (str.Length > i + 1)
                        if (str[i + 1] == 'h')
                        {
                            res += 'ш';
                            i++;
                        }
                        else if (str[i + 1] == 'c')
                        {
                            if (str.Length > i + 2)
                                if (str[i + 2] == 'h')
                                {
                                    res += 'щ';
                                    i++;
                                }
                                else
                                    res += 'с';
                            else
                                res += 'с';
                        }
                        else
                            res += 'с';
                    else
                        res += 'с';
                else if (str[i] == 't')
                    if (str.Length > i + 1)
                        if (str[i + 1] == 's')
                        {
                            res += 'ц';
                            i++;
                        }
                        else
                            res += 'т';
                    else
                        res += 'т';
                else if (str[i] == 'u')
                    res += 'у';
                else if (str[i] == 'f')
                    res += 'ф';
                else if (str[i] == 'h')
                    res += 'х';
                else if (str[i] == 'c')
                    if (str.Length > i + 1)
                        if (str[i + 1] == 'h')
                        {
                            res += 'ч';
                            i++;
                        }
                        else
                            res += 'с';
                    else
                        res += 'с';


                else if (str[i] == 'i')
                    res += "ы";
                else if (str[i] == 'e')
                    res += "э";
                else if (str[i] == 'y')
                    if (str.Length > i + 1)
                        if (str[i + 1] == 'u')
                        {
                            res += 'ю';
                            i++;
                        }
                        else if (str[i + 1] == 'a')
                        {
                            res += 'я';
                            i++;
                        }
                        else if (str[i + 1] == 'o')
                        {
                            res += 'ё';
                            i++;
                        }
                        else if (str[i + 1] == 'e')
                        {
                            res += 'е';
                            i++;
                        }
                        else
                            res += 'й';
                    else
                        res += 'й';
            }
            return res;
        }

        public static string ChangeKeyBoard(this string str)
        {
            string res = "";
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == 'а')
                    res += 'f';
                else if (str[i] == 'б')
                    res += ',';
                else if (str[i] == 'в')
                    res += 'd';
                else if (str[i] == 'г')
                    res += 'u';
                else if (str[i] == 'д')
                    res += 'l';
                else if (str[i] == 'е')
                    res += 't';
                else if (str[i] == 'ё')
                    res += '`';
                else if (str[i] == 'ж')
                    res += ';';
                else if (str[i] == 'з')
                    res += 'p';
                else if (str[i] == 'и')
                    res += 'b';
                else if (str[i] == 'й')
                    res += 'q';
                else if (str[i] == 'к')
                    res += 'r';
                else if (str[i] == 'л')
                    res += 'k';
                else if (str[i] == 'м')
                    res += 'v';
                else if (str[i] == 'н')
                    res += 'y';
                else if (str[i] == 'о')
                    res += 'j';
                else if (str[i] == 'п')
                    res += 'g';
                else if (str[i] == 'р')
                    res += 'h';
                else if (str[i] == 'с')
                    res += 'c';
                else if (str[i] == 'т')
                    res += 'n';
                else if (str[i] == 'у')
                    res += 'e';
                else if (str[i] == 'ф')
                    res += 'a';
                else if (str[i] == 'х')
                    res += '[';
                else if (str[i] == 'ц')
                    res += "w";
                else if (str[i] == 'ч')
                    res += "x";
                else if (str[i] == 'ш')
                    res += "i";
                else if (str[i] == 'щ')
                    res += "o";
                else if (str[i] == 'ъ')
                    res += "]";
                else if (str[i] == 'ы')
                    res += "s";
                else if (str[i] == 'ь')
                    res += "m";
                else if (str[i] == 'э')
                    res += "'";
                else if (str[i] == 'ю')
                    res += ".";
                else if (str[i] == 'я')
                    res += "z";
                else if (str[i] == '.')
                    res += "/";
                else if (str[i] == ',')
                    res += "?";

                else if (str[i] == 'f')
                    res += 'а';
                else if (str[i] == ',')
                    res += 'б';
                else if (str[i] == 'd')
                    res += 'в';
                else if (str[i] == 'u')
                    res += 'г';
                else if (str[i] == 'l')
                    res += 'д';
                else if (str[i] == 't')
                    res += 'е';
                else if (str[i] == '`')
                    res += 'ё';
                else if (str[i] == ';')
                    res += 'ж';
                else if (str[i] == 'p')
                    res += 'з';
                else if (str[i] == 'b')
                    res += 'и';
                else if (str[i] == 'q')
                    res += 'й';
                else if (str[i] == 'r')
                    res += 'к';
                else if (str[i] == 'k')
                    res += 'л';
                else if (str[i] == 'v')
                    res += 'м';
                else if (str[i] == 'y')
                    res += 'н';
                else if (str[i] == 'j')
                    res += 'о';
                else if (str[i] == 'g')
                    res += 'п';
                else if (str[i] == 'h')
                    res += 'р';
                else if (str[i] == 'c')
                    res += 'с';
                else if (str[i] == 'n')
                    res += 'т';
                else if (str[i] == 'e')
                    res += 'у';
                else if (str[i] == 'a')
                    res += 'ф';
                else if (str[i] == '[')
                    res += 'х';
                else if (str[i] == 'w')
                    res += "ц";
                else if (str[i] == 'x')
                    res += "ч";
                else if (str[i] == 'i')
                    res += "ш";
                else if (str[i] == 'o')
                    res += "щ";
                else if (str[i] == ']')
                    res += "ъ";
                else if (str[i] == 's')
                    res += "ы";
                else if (str[i] == 'm')
                    res += "ь";
                else if (str[i] == '\'')
                    res += "э";
                else if (str[i] == '.')
                    res += "ю";
                else if (str[i] == 'z')
                    res += "я";
            }
            return res;
        }
    }
}
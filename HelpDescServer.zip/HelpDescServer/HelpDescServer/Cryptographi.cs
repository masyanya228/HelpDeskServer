﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    class Cryptographi
    {
        //private static readonly byte[] Salt = Encoding.ASCII.GetBytes("o6806642kbM7c5");

        /// <summary>
        /// Encrypt the given string using AES.  The string can be decrypted using 
        /// DecryptStringAES().  The sharedSecret parameters must match.
        /// </summary>
        /// <param name="plainText">The text to encrypt.</param>
        /// <param name="sharedSecret">A password used to generate a key for encryption.</param>
        public static string EncryptStringAES(string plainText, string sharedSecret)
        {
            if (string.IsNullOrEmpty(plainText))
                throw new ArgumentNullException("plainText");
            if (string.IsNullOrEmpty(sharedSecret))
                throw new ArgumentNullException("sharedSecret");

            string outStr;                       // Encrypted string to return
            RijndaelManaged aesAlg = null;              // RijndaelManaged object used to encrypt the data.

            try
            {
                aesAlg = new RijndaelManaged();
                aesAlg.Mode = CipherMode.CBC;
                aesAlg.Padding = PaddingMode.ISO10126;
                aesAlg.GenerateIV();
                var key = new Rfc2898DeriveBytes(sharedSecret, aesAlg.IV);
                aesAlg.Key = key.GetBytes(aesAlg.KeySize / 8);


                // Create a decryptor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor();

                // Create the streams used for encryption.
                using (var msEncrypt = new MemoryStream())
                {
                    // prepend the IV
                    msEncrypt.Write(BitConverter.GetBytes(aesAlg.IV.Length), 0, sizeof(int));
                    msEncrypt.Write(aesAlg.IV, 0, aesAlg.IV.Length);
                    using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (var swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                    }
                    outStr = Convert.ToBase64String(msEncrypt.ToArray());
                }
            }
            finally
            {
                // Clear the RijndaelManaged object.
                if (aesAlg != null)
                    aesAlg.Clear();
            }

            // Return the encrypted bytes from the memory stream.
            return outStr;
        }

        /// <summary>
        /// Decrypt the given string.  Assumes the string was encrypted using 
        /// EncryptStringAES(), using an identical sharedSecret.
        /// </summary>
        /// <param name="cipherText">The text to decrypt.</param>
        /// <param name="sharedSecret">A password used to generate a key for decryption.</param>
        public static string DecryptStringAES(string cipherText, string sharedSecret)
        {
            if (string.IsNullOrEmpty(cipherText))
                throw new ArgumentNullException("cipherText");
            if (string.IsNullOrEmpty(sharedSecret))
                throw new ArgumentNullException("sharedSecret");

            // Declare the RijndaelManaged object
            // used to decrypt the data.
            RijndaelManaged aesAlg = null;
            // Declare the string used to hold
            // the decrypted text.
            string plaintext;

            try
            {

                // Create the streams used for decryption.                
                byte[] bytes = Convert.FromBase64String(cipherText);
                using (var msDecrypt = new MemoryStream(bytes))
                {
                    // Create a RijndaelManaged object
                    // with the specified key and IV.
                    aesAlg = new RijndaelManaged();
                    aesAlg.Mode = CipherMode.CBC;
                    aesAlg.Padding = PaddingMode.ISO10126;
                    // Get the initialization vector from the encrypted stream
                    aesAlg.IV = ReadByteArray(msDecrypt);
                    var key = new Rfc2898DeriveBytes(sharedSecret, aesAlg.IV);
                    aesAlg.Key = key.GetBytes(aesAlg.KeySize / 8);
                    // Create a decrytor to perform the stream transform.
                    ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                    using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (var srDecrypt = new StreamReader(csDecrypt))

                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            plaintext = srDecrypt.ReadToEnd();
                    }
                }
            }
            finally
            {
                // Clear the RijndaelManaged object.
                if (aesAlg != null)
                    aesAlg.Clear();
            }

            return plaintext;
        }

        private static byte[] ReadByteArray(Stream s)
        {
            var rawLength = new byte[sizeof(int)];
            if (s.Read(rawLength, 0, rawLength.Length) == rawLength.Length)
            {
                var buffer = new byte[BitConverter.ToInt32(rawLength, 0)];
                if (s.Read(buffer, 0, buffer.Length) != buffer.Length)
                {
                    throw new SystemException("Did not read byte array properly");
                }

                return buffer;
            }

            throw new SystemException("Stream did not contain properly formatted byte array");
        }

        public static string GetSHA512(string txt)
        {
            //1234567890636943207151081091ujJTh2rta8ItSm/1PYQGxq2GQZXtFEq1yHYhtsIztUi66uaVbfNG7IwX9eoQ817jy8UUeX7X3dMUVGTioLq0Ew==
            //1234567890636943207151070000ujJTh2rta8ItSm/1PYQGxq2GQZXtFEq1yHYhtsIztUi66uaVbfNG7IwX9eoQ817jy8UUeX7X3dMUVGTioLq0Ew==

            //sOsyff01d6bgt1CymDJZ7xzklcVu2TV++L9QEypfrxqM1R4QNuzGakCJvap4BKB/D5izsSNhv1YyEhlIvHf3CA==
            var cr = new SHA512CryptoServiceProvider();
            byte[] hashRes = cr.ComputeHash(Encoding.UTF8.GetBytes(txt));
            string res = Convert.ToBase64String(hashRes);
            return res;
        }

        static string alphabet = "0123456789QWERTYUIOPASDFGHJKLZXCVBNM";
        static Random ran = new Random();
        public static string GetRandom(int length = 4)
        {
            string res = "";
            while (length > 0)
            {
                res += alphabet[ran.Next(0, alphabet.Length)];
                length--;
            }
            return res;
        }
    }
    public class RSACrypt
    {
        public RSACryptoServiceProvider RsaInt;
        public RSACryptoServiceProvider RsaExt;
        public RSAParameters m_ExternKey;
        public RSAParameters m_InternKey;
        public string publickey;
        public string privatekey;
        public int Stage = 0;
        public static int keyLength = 1024;
        public RSACrypt()
        {
            RsaInt = new RSACryptoServiceProvider(keyLength);
            m_InternKey = RsaInt.ExportParameters(true);
            publickey = RsaInt.ToXmlString(false); //получим открытый ключ
            privatekey = RsaInt.ToXmlString(true); //получим закрытый ключ
        }

        /*public string Export()
        {
            var export = RsaKey.ExportParameters(false);
        }*/

        public RSACrypt(string modulus, string exponent)
        {
            RsaInt = new RSACryptoServiceProvider();
            RSAParameters parameters = new RSAParameters();
            parameters.Modulus = BigInteger.Parse(modulus, NumberStyles.HexNumber).ToByteArray();
            parameters.Exponent = BigInteger.Parse(exponent, NumberStyles.HexNumber).ToByteArray();
            RsaInt.ImportParameters(parameters);
            publickey = RsaInt.ToXmlString(false); //получим открытый ключ
        }
        /// <summary>
        /// Restricted
        /// </summary>
        /// <param name="param"></param>
        public RSACrypt(string param)
        {
            RsaInt = new RSACryptoServiceProvider();
            RsaInt.FromXmlString(param); //получим открытый ключ
            publickey = RsaInt.ToXmlString(false); //получим открытый ключ
        }

        public void SetExtRSA(RSAParameters param)
        {
            RsaExt = new RSACryptoServiceProvider(keyLength);
            RsaExt.ImportParameters(param);
            //publickey = RsaKey.ToXmlString(false);
        }

        public byte[] Encrypt(string txt)
        {
            byte[] data = Encoding.UTF8.GetBytes(txt);
            return Encrypt(data);
        }

        public byte[] Encrypt(byte[] bytes)
        {
            int maxsize = RsaExt.KeySize / 8 - 11;
            List<byte> EncryptedData = new List<byte>();
            try
            {
                for (int i = 0; i < bytes.Length; i += maxsize)
                    EncryptedData.AddRange(RsaExt.Encrypt(bytes.Skip(i).Take(maxsize).ToArray(), false));
            }
            catch
            {
                EncryptedData = new List<byte>();
            }
            return EncryptedData.ToArray();
        }

        public byte[] EncryptSelf(string txt)
        {
            byte[] data = Encoding.UTF8.GetBytes(txt);
            return EncryptSelf(data);
        }

        public byte[] EncryptSelf(byte[] bytes)
        {
            int maxsize = RsaInt.KeySize / 8 - 11;
            List<byte> EncryptedData = new List<byte>();
            try
            {
                for (int i = 0; i < bytes.Length; i += maxsize)
                    EncryptedData.AddRange(RsaInt.Encrypt(bytes.Skip(i).Take(maxsize).ToArray(), false));
            }
            catch
            {
                EncryptedData = new List<byte>();
            }
            return EncryptedData.ToArray();
        }

        public string Decrypt(byte[] data)
        {
            int maxsize = RsaExt.KeySize / 8;
            List<byte> DecryptedData = new List<byte>();
            try
            {
                for (int i = 0; i < data.Length; i += maxsize)
                    DecryptedData.AddRange(RsaInt.Decrypt(data.Skip(i).Take(maxsize).ToArray(), false));
            }
            catch (Exception ex)
            {
                DecryptedData = new List<byte>();
            }
            string result = Encoding.UTF8.GetString(DecryptedData.ToArray());
            return result;
        }

        public static byte[] SetLength(byte[] msg)
        {
            byte[] bytes = BitConverter.GetBytes(msg.Length);
            return bytes.Concat(msg).ToArray();
        }

        public static int GetLength(byte[] msg)
        {
            return BitConverter.ToInt32(msg, 0); ;
        }
    }
}
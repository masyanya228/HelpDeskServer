﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class Session
    {
        public static Dictionary<string, Session> Sessions = new Dictionary<string, Session>();

        public string IP;
        public User User;
        public string KeyID;
        public RSACrypt RSA;
        public DateTime Creation = new DateTime();
        public DateTime LastConnection = new DateTime();

        public Session(string iP, RSACrypt rSA)
        {
            IP = iP;
            RSA = rSA;
            KeyID = Cryptographi.GetRandom(16);
        }

        public static Session GetById(string KeyID)
        {
            try
            {
                var res = Sessions.FirstOrDefault(x => x.Key == KeyID);
                return res.Value;
            }
            catch
            {
                return null;
            }
        }

        public static void ClearOld()
        {
            foreach (string key in Sessions.Keys)
            {
                if (DateTime.Now.Subtract(Sessions[key].LastConnection).TotalSeconds > 5 * 60)
                {
                    Sessions.Remove(key);
                }
            }
        }
    }
}
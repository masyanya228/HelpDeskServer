﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Net;

namespace HelpDescServer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static ServerMain serMain;
        public static CodeFirstContext Context;

        private void Form1_Load(object sender, EventArgs e)
        {
            string tr = "яйцо".Translit();
            tr = tr.Translit();
            ServerMain.Controls.Add("con", textBox2);
            //Context = new CodeFirstContext();
            groupBox1.Dock = DockStyle.Fill;
            groupBox2.Dock = DockStyle.Fill;
            groupBox3.Dock = DockStyle.Fill;
            groupBox4.Dock = DockStyle.Fill;
            HideAll();
            //Clients.Init();
            //while (!Clients.Ready) { }
            List<long> swres = new List<long>();
            Stopwatch sw = new Stopwatch();
            sw.Start();
            /*for (int i = 0; i < 5; i++)
            {
                for (int n = 0; n < 100; n++)
                {
                    if (Clients.AddRequest(new string[] { "1111", "ПК", "Хабибуллин М.Э.", "Без описания" }, out string err))
                    {

                    }
                    else
                    {

                    }
                }
                swres.Add(sw.ElapsedMilliseconds);
            }
            var all = Clients.GetRequests();
            swres.Add(sw.ElapsedMilliseconds);
            var seim = Clients.GetLastNRequests(250);
            swres.Add(sw.ElapsedMilliseconds);*/
            sw.Stop();

            numericUpDown1.Maximum = UInt16.MaxValue;
            ToolTip t = new ToolTip();
            t.SetToolTip(label1, "Вычисляется по времени задействия ядер");


            int port = 80;
            if (File.Exists(Environment.CurrentDirectory + "\\Settings.txt"))
            {
                StreamReader r = new StreamReader(Environment.CurrentDirectory + "\\Settings.txt");
                string[] lines = r.ReadToEnd().Replace("\r", "").Split('\n');
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] par = TrueSplit(lines[i]);
                    if (par[0] == "port")
                    {
                        if (par[1] != null)
                        {
                            if (int.TryParse(par[1], out port))
                            {
                                new ServerMain(port, SynchronizationContext.Current);
                            }
                        }
                    }
                }
                r.Close();
            }
            Task.Factory.StartNew(() =>
            {
                bool reset = true;
                int tring = 0;
            A: try
                {
                    if (reset)
                    {
                        reset = false;
                        int k = 1;
                        int n = 1 / (k - 1);
                    }
                    tring++;
                    User[] users = User.Users.ToArray();
                    Role[] roles = Role.Roles.ToArray();
                    Permision[] perms = Permision.Permisions.ToArray();
                    TaskType[] types = TaskType.TaskTypes.ToArray();
                    TaskStage[] stages = TaskStage.TaskStages.ToArray();
                    TicketTask[] tickets = TicketTask.TicketTasks.ToArray();
                    //Context.TicketTasks.RemoveRange(Context.TicketTasks);
                    //bool res = User.TestCase(Context);
                    bool res1 = TicketTask.TestCase(Context);
                    //Context.SaveChanges();
                    TaskUpdates taskUpdates = new TaskUpdates("Gray^Серый^ светлее&DateTime&");
                    string[][] LineUp = taskUpdates.GetLine();

                    var searchres = Permision.GetTreeByName(Context, "");
                    searchres = Permision.GetTreeByName(Context, ".");
                    searchres = Permision.GetTreeByName(Context, "Hello");
                    searchres = Permision.GetTreeByName(Context, "Rol");
                    searchres = Permision.GetTreeByName(Context, "Rol.");
                    searchres = Permision.GetTreeByName(Context, "Roles");
                    searchres = Permision.GetTreeByName(Context, "Roles.");
                    searchres = Permision.GetTreeByName(Context, "Roles.Delete");
                    searchres = Permision.GetTreeByName(Context, "Roles.per");
                    searchres = Permision.GetTreeByName(Context, "Roles.per.delete");
                    searchres = Permision.GetTreeByName(Context, "Roles..delete");
                    searchres = Permision.GetTreeByName(Context, ".delete");
                    searchres = Permision.GetTreeByName(Context, "..delete");
                    searchres = Permision.GetTreeByName(Context, "Roles.Dele");

                    var searchresusers = User.SearchByLogin(Context, "");
                    searchresusers = User.SearchByLogin(Context, "mor");
                    searchresusers = User.SearchByLogin(Context, "abr");
                    searchresusers = User.SearchByLogin(Context, "te ste er");

                    searchresusers = User.SearchByText(Context, "");
                    searchresusers = User.SearchByText(Context, "2019");
                    searchresusers = User.SearchByText(Context, "хабиб");

                    searchresusers = User.SearchByText(Context, "s");
                    searchresusers = User.SearchByText(Context, "sy");
                    searchresusers = User.SearchByText(Context, "sys");
                    searchresusers = User.SearchByText(Context, "syst");
                    searchresusers = User.SearchByText(Context, "syste");
                    searchresusers = User.SearchByText(Context, "system");
                    searchresusers = User.SearchByText(Context, "sysem");
                    searchresusers = User.SearchByText(Context, "syshtem");
                    searchresusers = User.SearchByText(Context, "systen");
                }
                catch (Exception ex)
                {
                    if (tring > 3)
                    {
                        MessageBox.Show("Критическая проблема с базой данных!!!\r\n" + ex.ToString(), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Application.Exit();
                    }
                    //Context.Database
                    //bool deleted = Context.Database.Delete();
                    //Context.Database.Create();
                    Permision.Creation(Context);
                    //Context.SaveChanges();
                    Role.Creation(Context);
                    //Context.SaveChanges();
                    User.Creation(Context);
                    //Context.SaveChanges();
                    TaskStage.Creation(Context);
                    //Context.SaveChanges();
                    TaskType.Creation(Context);
                    //Context.SaveChanges();
                    goto A;
                }
            }).Wait(10000);
            timer1.Start();
        }

        public void HideAll()
        {
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
        }
        public void ShowOne(Control control)
        {
            HideAll();
            control.Visible = true;
        }

        public static string[] TrueSplit(string input, string ch = "=")
        {
            int pos = input.IndexOf(ch);
            if (pos >= 0)
            {
                return new string[2] { input.Substring(0, pos), input.Substring(pos + 1) };
            }
            return new string[2] { input, null };
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            decimal cpustress = Profiling.GetAllLoad();
            ProgressCPUstress.Size = new Size((int)(cpustress / 1 * label1.Width), ProgressCPUstress.Size.Height);
            lock (ServerMain.Servers)
            {
                int sum = 0;
                for (int i = 0; i < ServerMain.Servers.Count; i++)
                {
                    sum += ServerMain.Servers[i].col;
                }
                label4.Text = sum + "";
            }
            label5.Text = Profiling.GetReqPerSec() + "";

            Profiling.CleaN();

            lock (ServerMain.Servers)
            {
                while (listBox1.Items.Count < ServerMain.Servers.Count)
                    listBox1.Items.Add(ServerMain.Servers[listBox1.Items.Count].tcpServer.LocalEndpoint.ToString().Substring(ServerMain.Servers[listBox1.Items.Count].tcpServer.LocalEndpoint.ToString().IndexOf(":") + 1));

                for (int i = 0; i < ServerMain.Servers.Count; i++)
                {
                    var ss = ServerMain.Servers[i];
                    listBox1.Items[i] = ss.tcpServer.LocalEndpoint.ToString().Substring(ss.tcpServer.LocalEndpoint.ToString().IndexOf(":") + 1) + "-" + ss.State.ToString();
                }

                while (listBox1.Items.Count > ServerMain.Servers.Count)
                    listBox1.Items.RemoveAt(ServerMain.Servers.Count);

                for (int i = 0; i < ServerMain.Servers.Count; i++)
                {
                    var ss = ServerMain.Servers[i];
                    if (ss.State == ServerMain.ServerState.Stoped)
                        ServerMain.Servers.Remove(ss);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new ServerMain((int)numericUpDown1.Value, SynchronizationContext.Current);
            ServerMain.SaveSettings();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lock (ServerMain.Servers)
            {
                if (listBox1.SelectedIndex >= 0 & ServerMain.Servers.Count > listBox1.SelectedIndex)
                {
                    ServerMain.Servers[listBox1.SelectedIndex].Stop();
                    ServerMain.SaveSettings();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lock (ServerMain.Servers)
            {
                if (listBox1.SelectedIndex >= 0 & ServerMain.Servers.Count > listBox1.SelectedIndex)
                {
                    ServerMain.Servers[listBox1.SelectedIndex].ReSet((int)numericUpDown1.Value);
                    ServerMain.SaveSettings();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedIndex >= 0 & ServerMain.Servers.Count > listBox1.SelectedIndex)
            {
                lock (ServerMain.Servers[listBox1.SelectedIndex].categories)
                {
                    ServerMain.Servers[listBox1.SelectedIndex].categories = textBox1.Text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                }
            }
        }

        private void пользователиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowOne(groupBox4);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Context.SaveChanges();
            //Context.Dispose();
        }

        private void БэкапToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string dbname = Context.Database.Connection.Database;
            string sqlCommand = @"BACKUP DATABASE [{0}] TO  DISK = N'{1}' WITH NOFORMAT, NOINIT,  NAME = N'MyAir-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10";
            Context.Database.ExecuteSqlCommand(System.Data.Entity.TransactionalBehavior.DoNotEnsureTransaction, string.Format(sqlCommand, dbname, "D:\\MSSQLBACKUP\\DBM.bak"));
        }
    }
}
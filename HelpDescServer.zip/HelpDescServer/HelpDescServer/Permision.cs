﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class Permision
    {
        public static List<Permision> Permisions = new List<Permision>();
        static string[] operations = new string[] {
            "add",
            "delete",
            "edit",
            "set",
            "view",
            "recover",
            "viewdeleted",
            "rerequest",
            "reset",
            "open",
            "close"
        };

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool outside = false;
        public Permision()
        {

        }
        public Permision(string name, string description)
        {
            Name = name;
            Description = description;
            Permisions.Add(this);
        }

        public override string ToString()
        {
            return Name ?? "Без имени";
        }

        /// <summary>
        /// Root.Tickets - Delete/Add
        /// Root.Tickets.Priority - Set/Edit
        /// Root.Tickets.Sender - Edit
        /// Root.Tickets.Type - Edit
        /// Root.Tickets.Desc - Edit
        /// Root.Tickets.ReqDate - Edit
        /// Root.Tickets.Stages - Add/Remove
        /// Root.Tickets.Agreement - Add/Remove/Edit
        /// </summary>
        /// <param name="context"></param> 
        public static void Creation(CodeFirstContext context)
        {
            string[] strtoPerm = new string[]
            {
                ".Tickets.View/Права для просмотра всех задач",//может просматривать все задачи
                ".Tickets.ViewDeleted/Права для просмотра удаленных задач",
                ".Tickets.Closed.View/Просмотр завершенных задач",
                ".Tickets.Closed.Open/Переоткрытие завершенных задач",
                ".Tickets.Deleted/Удаление задач",
                ".Tickets.Close/Завершение задач",
                ".Tickets.Recover/Восстановление удаленных задач",
                ".Tickets.Priority.Set/Первичная установка приоритет",
                ".Tickets.Priority.Edit/Изменение приоритета",
                ".Tickets.Stages.Add/Добавление этапов",
                ".Tickets.Stages.Delete/Удаление этапов",
                ".Tickets.Comments.Edit/Редактирование комментариев - полный доступ к редактированию",
                ".Tickets.Comments.Add/Добавление нового комментария",

                ".Agreements.Visor.Edit/Позволяет решать задачи к котороым ты имеешь доступ, даже при условии что согласование возложенно на другого человека",
                ".Agreements.ReRequest/Разрешает перезапрашивать согласования",
                ".Agreements.Delete/Разрешает удалять согласования",
                ".Agreements.Reset/Разрешает сбрасывать согласование, тем самым делая его открытым",
                ".Agreements.Add/Позволяет добавлять согласования",

                ".Users.View/Разрешает пользоваться полнотекстовые поиском, раскрывая данные о всех пользователях",
                ".Users.ViewDeleted/Позволяет просматривать удаленных пользователей",
                ".Users.Add/Дает возможность добавлять пользователей",
                ".Users.Delete/Дает возможность удалять пользователей",
                ".Users.Recover/Дает возможность восстанавливать пользователей",
                ".Users.Restricted.Delete/Дает возможность удалять права из списка ЗАПРЕТОВ пользователя",
                ".Users.Restricted.Add/Дает возможность добавлять права в списк ЗАПРЕТОВ пользователя",
                ".Users.Roles.Delete/Дает возможность удалять роли у пользователей",
                ".Users.Roles.Add/Дает возможность добавлять роли пользователям",
                ".Users.Login.Edit/Дает возможность изменять логин пользователя",
                ".Users.FullName.Edit/Дает возможность изменять полное имя пользователя",
                ".Users.LoginOfLeader.Edit/Позволяет возможность изменять руководителя у пользователя",
                ".Users.Block.Set/Дает возможность блокировать пользователя",
                ".Users.Block.Delete/Дает возможность разблокировать пользователя",
                ".Users.BlockInTasks.Set/Дает возможность блокировать пользователя для участия в задачах",
                ".Users.BlockInTasks.Delete/Дает возможность убирать блокировку пользователя в задачах",
                ".Users.Location.Edit/Дает возможность изменять локацию пользователя",
                ".Users.CoolDown.Delete/Дает возможность убирать временную блокировку пользователя",
                ".Users.Pass.Edit/Позволяет изменять пароль пользователя",

                ".Permissions.View",
                ".Permissions.ViewDeleted",
                ".Permissions.Description.Edit",
                ".Permissions.Hiden.Edit",

                ".Roles.View",
                ".Roles.Add",
                ".Roles.Recover",
                ".Roles.Delete",
                ".Roles.ViewDeleted",
                ".Roles.Name.Edit",
                ".Roles.Description.Edit",
                ".Roles.Permissions.Add",
                ".Roles.Permissions.Delete",
                ".Roles.IsDefaultLeader.Edit",
                ".Roles.IsDefault.Edit",

                ".Stages.View",
                ".Stages.ViewDeleted",
                ".Stages.Add",
                ".Stages.Recover",
                ".Stages.Delete",
                ".Stages.Description.Edit",
                ".Stages.Autopick.Edit",
                ".Stages.SLA.Edit",
                ".Stages.Name.Edit",
                ".Stages.Roles.Add",
                ".Stages.Roles.Delete",

                ".Types.View",
                ".Types.Delete",
                ".Types.ViewDeleted",
                ".Types.Add",
                ".Types.Recover",
                ".Types.Description.Edit",
                ".Types.Stages.Add",
                ".Types.Stages.Delete",
                ".Types.Name.Edit",
                ".Types.IsDefault.Edit",
                };

            for (int i = 0; i < strtoPerm.Length; i++)
            {
                var args = Form1.TrueSplit(strtoPerm[i], "/");
                Permision permision = new Permision(args[0], args[1]);
                //context.Permisions.Add(permision);
            }
        }

        public static Permision GetByName(CodeFirstContext context, string name)
        {
            foreach (Permision permision in Permisions)
            {
                if (permision.Name.ToLower() == name.ToLower())
                    return permision;
            }
            return null;
        }

        public static Permision[] GetAll(CodeFirstContext context)
        {
            List<Permision> result = new List<Permision>();
            foreach (Permision permision in Permisions)
            {
                result.Add(permision);
            }
            return result.ToArray();
        }

        public static Permision[] GetTreeByName(CodeFirstContext context, string name)
        {
            if (!name.StartsWith("."))
                name = "." + name;
            List<Permision> result = new List<Permision>();
            int pos = name.LastIndexOf(".");
            string operation = name.Substring(pos + 1);
            if (operations.ToList().IndexOf(operation.ToLower()) >= 0)
                name = name.Remove(pos);
            else
            {
                if (operation == "")
                {
                    name = name.Remove(pos);
                }
                operation = " ";
            }
            foreach (Permision permision in Permisions)
            {
                if (permision.Name.ToLower().StartsWith(name.ToLower()))
                    if (operation == " " ? true : (permision.Name.ToLower().EndsWith(operation.ToLower())))
                        result.Add(permision);
            }
            return result.ToArray();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class User
    {
        public static List<User> Users = new List<User>();
        public int Id { get; set; }
        public string FullName { get; set; } = "";
        public string Login { get; set; } = "";
        public string LoginOfLeader { get; set; } = "";
        public string Pass { get; set; } = "";
        public DateTime RegDate { get => regDate; set => regDate = value; }
        public virtual List<Role> Roles { get => roles; set => roles = value; }
        public string Location { get; set; } = "";
        public virtual List<Permision> Restricted { get => restricted; set => restricted = value; }
        public virtual List<Notifi> Notifis { get => notifis; set => notifis = value; }
        public bool Deleted { get; set; } = false;
        public bool Blocked { get; set; } = false;
        public bool BlockedInTasks { get; set; } = false;
        public DateTime CoolDownExpire { get => coolDownExpire; set => coolDownExpire = value; }

        [NotMapped]
        public double SLALast;
        [NotMapped]
        public static string Sole = "1234567890";
        private List<Permision> restricted = new List<Permision>();
        private List<Role> roles = new List<Role>();
        private List<Notifi> notifis = new List<Notifi>();
        private DateTime coolDownExpire = DateTime.Now;
        private DateTime regDate = DateTime.Now;

        public User()
        {
            Id = getId();
            Users.Add(this);
        }
        public int getId()
        {
            return Users.Count > 0 ? Users[Users.Count - 1].Id + 1 : 0;
        }
        public override string ToString()
        {
            return (Login ?? "Без имени") + (FullName == null ? "" : "(" + FullName + ")");
        }

        public static bool TestCase(CodeFirstContext context)
        {
            int size = 10;
            int count = context.Users.Count();
            List<User> users = new List<User>();
            for (int i = 0; i < size; i++)
            {
                User user = new User();
                user.FullName = "Хабибуллин Марсель Эдуардович";
                user.Login = "Mors" + i;
                user.RegDate = DateTime.Now;
                users.Add(user);
                context.Users.Add(user);
            }
            context.SaveChanges();
            count = context.Users.Count() - count;
            for (int i = 0; users.Count > 0; i++)
            {
                context.Users.Remove(users[0]);
                users.Remove(users[0]);
            }
            context.SaveChanges();
            return size == count;
        }

        public static void Creation(CodeFirstContext context)
        {
            User user = new User()
            {
                FullName = "Хабибуллин Марсель Эдуардович",
                Login = "Mors",
                RegDate = DateTime.Now,
            };
            //NttKR6o7pBAu2wwRKBuLcqAQQcEAE7MQl23xTa61BeSx+z9JIk4J55wlLWsrz2H6wC+ByQTPxB68CAklwiQ+Jw==
            user.SavePass(Cryptographi.GetSHA512("123456"));
            user.Roles.Add(Role.GetByName(context, "Super.Admin"));
            user.Roles.AddRange(Role.GetAllWithOutPermisions(context));
            //context.Users.Add(user);

            user = new User()
            {
                FullName = "Человек Выставляющий Приоритет",
                Login = "test1",
                RegDate = DateTime.Now
            };
            user.SavePass(Cryptographi.GetSHA512("123456"));
            user.Roles.Add(Role.GetByName(context, "Priority Manager"));
            //context.Users.Add(user);

            user = new User()
            {
                FullName = "Рук",
                Login = "test2",
                RegDate = DateTime.Now
            };
            user.SavePass(Cryptographi.GetSHA512("123456"));
            user.Roles.Add(Role.GetByName(context, "Руководитель"));
            //context.Users.Add(user);

            user = new User()
            {
                FullName = "спец",
                Login = "test3",
                RegDate = DateTime.Now
            };
            user.SavePass(Cryptographi.GetSHA512("123456"));
            user.Roles.Add(Role.GetByName(context, "специалист"));
            //context.Users.Add(user);

            user = new User()
            {
                FullName = "глав бух",
                Login = "test4",
                RegDate = DateTime.Now
            };
            user.SavePass(Cryptographi.GetSHA512("123456"));
            user.Roles.Add(Role.GetByName(context, "бухгалтерия"));
            //context.Users.Add(user);

            user = new User()
            {
                FullName = "System Manager Accaunt",
                Login = "system",
                RegDate = DateTime.Now
            };
            user.SavePass(Cryptographi.GetSHA512("password"));
            user.Restricted.AddRange(Permision.GetAll(context));
            //context.Users.Add(user);

            /*for (int i = 0; i < 100; i++)
            {
                user = new User()
                {
                    FullName = "Тестеров Тестер Тестерович",
                    Login = "tester" + i,
                    RegDate = DateTime.Now
                };
                user.SavePass(Cryptographi.GetSHA512("123456"));
                user.Roles.Add(Role.GetByName(context));
                //context.Users.Add(user);
            }*/
        }

        public double GetSLAsum()
        {
            double res = 0;
            //Slowly
            var alltickets = TicketTask.GetAll(Form1.Context, -1, true);
            for (int i = 0; i < alltickets.Length; i++)
            {
                for (int j = 0; j < alltickets[i].Agreements.Count; j++)
                {
                    if (alltickets[i].Agreements[j].Visor == this)
                    {
                        res += alltickets[i].Agreements[j].TaskStage.SLAminute;
                    }
                }
            }
            return res;
        }


        public void SavePass(string passHash)
        {
            Pass = Cryptographi.GetSHA512(Sole + RegDate.DateToString() + passHash);
        }

        public bool CheckPass(string passHash)
        {
            //ujJTh2rta8ItSm/1PYQGxq2GQZXtFEq1yHYhtsIztUi66uaVbfNG7IwX9eoQ817jy8UUeX7X3dMUVGTioLq0Ew==
            //ujJTh2rta8ItSm/1PYQGxq2GQZXtFEq1yHYhtsIztUi66uaVbfNG7IwX9eoQ817jy8UUeX7X3dMUVGTioLq0Ew==

            //hQ/YkSLwrqz984TNUbjN2RiGNAYl7YltfL0FK4iFSHijIm14HW6dMOxDk6EyZNVb/tdL5+gwyoONcVVmbk6TEA==
            //hQ/YkSLwrqz984TNUbjN2RiGNAYl7YltfL0FK4iFSHijIm14HW6dMOxDk6EyZNVb/tdL5+gwyoONcVVmbk6TEA==

            //NttKR6o7pBAu2wwRKBuLcqAQQcEAE7MQl23xTa61BeSx+z9JIk4J55wlLWsrz2H6wC+ByQTPxB68CAklwiQ+Jw== -Pass

            //b0G0W3npraNKqNEAk3qKG+Peym4GXZkqCQqfnQX1n+p2zla9BYnLuHHFMoS7fcZRd7+aKloa0XuK/hjWoyVPqg== -NewPass
            return Cryptographi.GetSHA512(Sole + RegDate.DateToString() + passHash) == Pass;
        }

        public Permision[] GetAllPermisions()
        {
            List<Permision> result = new List<Permision>();
            foreach (Role role in Roles)
                result.AddRange(role.GetAllPermisions());
            foreach (Permision permision in Restricted)
                result.Remove(permision);
            return result.ToArray();
        }

        public bool HavePermision(string permisionName)
        {
            Permision[] result = GetAllPermisions();
            for (int i = 0; i < result.Length; i++)
            {
                if (permisionName.ToLower() == result[i].Name.ToLower())
                    return true;
            }
            return false;
        }

        public bool HaveTreePermision(string permisionName)
        {
            Permision[] result = GetAllPermisions();
            for (int i = 0; i < result.Length; i++)
            {
                if (result[i].Name.ToLower().StartsWith(permisionName.ToLower()))
                    return true;
            }
            return false;
        }

        public bool HaveAllPermision(params string[] permisionName)
        {
            int col = permisionName.Length;
            Permision[] result = GetAllPermisions();
            for (int j = 0; j < permisionName.Length; j++)
            {
                for (int i = 0; i < result.Length; i++)
                {
                    if (permisionName[j].ToLower() == result[i].Name.ToLower())
                    {
                        col--;
                        break;
                    }
                }
            }
            return col == 0;
        }

        public bool HaveOnePermision(params string[] permisionName)
        {
            Permision[] result = GetAllPermisions();
            for (int j = 0; j < permisionName.Length; j++)
            {
                for (int i = 0; i < result.Length; i++)
                {
                    if (permisionName[j].ToLower() == result[i].Name.ToLower())
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public bool CanDoRole(Role role)
        {
            Permision[] result = role.GetAllPermisions();
            if (result.Length > 0)
            {
                for (int i = 0; i < result.Length; i++)
                {
                    if (!HavePermision(result[i].Name))
                        return false;
                }
                return true;
            }
            else
            {
                if (Roles.IndexOf(role) >= 0)
                    return true;
                return false;
            }
        }

        public static User[] GetWithRole(Role role, bool withdel = false)
        {
            List<User> users = new List<User>();
            foreach (User user in Users)
            {
                if (!user.Deleted | withdel)
                    if (user.CanDoRole(role))
                        users.Add(user);
            }
            return users.ToArray(); ;
        }

        public static User GetByLogin(CodeFirstContext context, string login, bool withdel = false)
        {
            foreach (User user in Users)
            {
                if (!user.Deleted | withdel)
                    if (user.Login.ToLower() == login.ToLower())
                        return user;
            }
            return null;
        }

        public static User[] SearchByLogin(CodeFirstContext context, string login, bool withdel = false)
        {
            List<User> users = new List<User>();
            foreach (User user in Users)
            {
                if (!user.Deleted | withdel)
                    if (user.Login.ToLower().StartsWith(login.ToLower()) | login == "")
                        users.Add(user);
            }
            return users.ToArray();
        }
        public static User[] SearchByText(CodeFirstContext context, string text, bool withdel = false)
        {
            var cachres = SearchCach.GetRes(text, typeof(User), new TimeSpan(0, 0, 30));
            if (cachres == null)
            {
                List<Result> results = new List<Result>();
                List<User> users = new List<User>();
                foreach (User user in Users)
                {
                    if (!user.Deleted | withdel)
                    {
                        if (text != "")
                        {
                            string a = user.Id + " " + user.Login + " " + user.LoginOfLeader + " " + user.FullName + " " + user.RegDate.DateToString() + " " + user.Roles.ToArray().ArrayToString() + " " + user.GetAllPermisions().ArrayToString();
                            double res = a.CompareString(text);
                            if (res > 0)
                            {
                                results.Add(new Result() { item = user, rank = res });
                            }
                        }
                        else
                        {
                            users.Add(user);
                        }
                    }
                }
                if (users.Count == 0)
                {
                    if (results.Count > 0)
                        results = results.OrderByDescending(x => x.rank).ToList();
                    for (int i = 0; i < results.Count; i++)
                    {
                        users.Add(results[i].item as User);
                    }
                }
                SearchCach.SetRes(text, typeof(User), users.ToArray());
                return users.ToArray();
            }
            else
            {
                return (cachres as User[]);
            }
        }
    }
    public class Result
    {
        public object item;
        public double rank;
    }
        public class SearchCach
    {
        public static Dictionary<string, SearchCach> results = new Dictionary<string, SearchCach>();
        public DateTime CreationTime;
        public string Text;
        public object Result;
        public Type Type;
        public static void SetRes(string text, Type type, object res)
        {
            if (results.ContainsKey(text))
                results[text] = new SearchCach(type.ToString() + text, type, res);
            else
                results.Add(text, new SearchCach(type.ToString() + text, type, res));
        }
        public static object GetRes(string text, Type type, TimeSpan Age)
        {
            if (results.ContainsKey(type.ToString() + text))
            {
                return DateTime.Now.Subtract(results[type.ToString() + text].CreationTime).TotalMinutes < Age.TotalMinutes ? results[type.ToString() + text].Result : null;
            }
            else
                return null;
        }

        public SearchCach(string text, Type Type, object result)
        {
            Text = text;
            Result = result;
            CreationTime = DateTime.Now;
        }
    }
}
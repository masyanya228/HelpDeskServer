﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace HelpDescServer
{
    public class ServerMain
    {
        public string[] categories = new string[0];

        public TcpListener tcpServer;
        public int col = 0;
        public static Thread th;
        public ServerState State;
        public SynchronizationContext synchronization;
        public static Dictionary<string, Control> Controls = new Dictionary<string, Control>();
        public enum ServerState
        {
            Working,
            Paused,
            NeedStoping,
            Stoped
        }

        public static List<ServerMain> Servers = new List<ServerMain>();
        public ServerMain(int port, SynchronizationContext synchronizationContext)
        {
            synchronization = synchronizationContext;
            while (State == ServerState.Working)
            {
                try
                {
                    tcpServer = new TcpListener(IPAddress.Any, port);
                    tcpServer.Start(300);
                    th = new Thread(new ParameterizedThreadStart(Back));
                    th.IsBackground = true;
                    th.Start(this);
                    Servers.Add(this);
                    /*var tas = Task.Factory.StartNew(() =>
                    {
                        Back(this);
                    });*/
                    break;
                }
                catch (Exception ex)
                {
                    Thread.Sleep(1000);
                }
            }
        }
        public static void SaveSettings()
        {
            StreamWriter wr = new StreamWriter(Environment.CurrentDirectory + "\\Settings.txt", false);
            lock (Servers)
            {
                for (int i = 0; i < Servers.Count; i++)
                {
                    if (Servers[i].State == ServerState.Working)
                        wr.WriteLine("port=" + Servers[i].tcpServer.LocalEndpoint.ToString().Substring(Servers[i].tcpServer.LocalEndpoint.ToString().IndexOf(":") + 1));
                }
            }
            wr.Close();
        }
        public bool Stop()
        {
            try
            {
                State = ServerState.NeedStoping;
                tcpServer.Stop();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// Semi useless
        /// </summary>
        /// <returns></returns>
        public bool Pause()
        {
            try
            {
                State = ServerState.Paused;
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// Useless
        /// </summary>
        /// <returns></returns>
        public bool Resume()
        {
            try
            {
                State = ServerState.Working;
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        public bool ReSet(int port)
        {
            try
            {
                tcpServer.Stop();
                State = ServerState.NeedStoping;
                while (State != ServerState.Stoped) { Thread.Sleep(100); }
                tcpServer = new TcpListener(IPAddress.Any, port);
                tcpServer.Start(300);
                th = new Thread(new ParameterizedThreadStart(Back));
                th.Start(this);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        static void Back(object obj)
        {
            ServerMain Ser = (obj as ServerMain);
            Ser.State = ServerState.Working;
            TcpListener tcpServer = Ser.tcpServer;
            while (Ser.State!= ServerState.NeedStoping)
            {
                try
                {
                    TcpClient Cl = tcpServer.AcceptTcpClient();
                    Ser.col++;
                    
                    string ip = Cl.Client.RemoteEndPoint.ToString();
                    IPAddress n = IPAddress.Parse(ip.Substring(0, ip.IndexOf(':')));
                    /*if (AbuseAPI.IPClient.Add(n, DateTime.Now))
                    {*/
                        Stopwatch sw = new Stopwatch();
                        sw.Start();
                        Stopwatch swall = new Stopwatch();
                        swall.Start();
                        Thread Thread = new Thread(new ParameterizedThreadStart(Read));
                        Thread.Start(new InfoToRead() { ser = Ser, cl = Cl, sw = sw, swall = swall });
                    /*}
                    else
                    {
                        Cl.Close();
                        Cl.Dispose();
                        Cl = null;
                    }*/
                }
                catch (Exception ex)
                {

                }
            }
            Ser.State = ServerState.Stoped;
        }
        struct InfoToRead
        {
            public ServerMain ser;
            public TcpClient cl;
            public Stopwatch sw;
            public Stopwatch swall;
            public Profiling.ProfilingCPU prof;
        }
        static void Read(object info)
        {
            while (((InfoToRead)info).ser.State == ServerState.Paused) { Thread.Sleep(100); }
            ReadEntry(info);
            ((InfoToRead)info).ser.col--;
        }
        static void ReadEntry(object info)
        {
            TcpClient Client = ((InfoToRead)info).cl;
            ServerMain Ser = ((InfoToRead)info).ser;
            int startt = Environment.TickCount;
            string Request = "";
            byte[] Buffer = new byte[1024];
            List<string> map = new List<string>();
            List<byte> bytes= new List<byte>();
            int Count;
            int pausenum = 0;
            int Length = -1;
            try
            {
                for (; Client.Connected;)
                {
                    if (Client.Available > 0)
                        Count = Client.GetStream().Read(Buffer, 0, Buffer.Length);
                    else
                        Count = 0;
                    if (Count > 0)
                    {
                        bytes.AddRange(Buffer.Take(Count).ToArray());
                        if (bytes.Count > 4 & Length == -1)
                        {
                            Length = RSACrypt.GetLength(bytes.ToArray());
                        }
                    }
                    Request += Encoding.Default.GetString(Buffer, 0, Count);
                    map.Add("add+" + Count);
                    /*if (Request.EndsWith("^"))
                    {
                        Request = Request.Remove(Request.Length - 1);
                        map.Add("bb^");
                        break;
                    }
                    else if (Request.StartsWith("GET") & Request.Replace("\r\n", "\r").EndsWith("\r\r"))
                    {
                        map.Add("bb\\r\\r");
                        break;
                    }
                    else if (Request.StartsWith("POST") & Request.IndexOf("\r\n\r\n") >= 0 & pausenum >= 2)
                    {
                        map.Add("bb\\r\\r");
                        break;
                    }*/
                    if (Length + 4 == bytes.Count)
                    {
                        break;
                    }
                    if (Count == 0)
                    {
                        map.Add("tpause-" + pausenum);
                        if (pausenum == 0)
                        {
                            ((InfoToRead)info).sw.Stop();
                            Thread.Sleep(15);
                            ((InfoToRead)info).sw.Start();
                        }
                        else if (pausenum == 1)
                        {
                            ((InfoToRead)info).sw.Stop();
                            Thread.Sleep(15);
                            ((InfoToRead)info).sw.Start();
                        }
                        else if (pausenum == 2)
                        {
                            ((InfoToRead)info).sw.Stop();
                            Thread.Sleep(15);
                            ((InfoToRead)info).sw.Start();
                        }
                        else if (pausenum == 3)
                        {
                            ((InfoToRead)info).sw.Stop();
                            Thread.Sleep(15);
                            ((InfoToRead)info).sw.Start();
                        }
                        else
                        {
                            break;
                        }
                        pausenum++;
                    }
                    else
                    {
                        pausenum = 0;
                    }
                    if (Environment.TickCount - startt >= 5000 & false)
                    {
                        map.Add("bbtout");
                        //Console.WriteLine("Time out");
                        Client.Close();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Http reading error " + Client.Client.RemoteEndPoint);
                if (Client.Connected)
                    Client.Close();
                return;
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Connected(http) " + Client.Client.RemoteEndPoint + " " + Request.Length + "\n" + Request);
            Console.ForegroundColor = ConsoleColor.Gray;
            Match ReqMatch = Regex.Match(Request, @"^\w+\s+([^\s\?]+)[^\s]*\s+HTTP/.*|");
            
            if (ReqMatch == Match.Empty)
            {
                SendError(Client, 400);
                return;
            }

            string RequestUri = ReqMatch.Groups[1].Value;
            if (RequestUri.IndexOf(":") >= 0)
            {
                RequestUri = RequestUri.Remove(0, RequestUri.IndexOf(":"));
            }
            if (RequestUri == "/")
            {
                RequestUri += "index.html";
            }
            for (int i = 0; i < ReqMatch.Groups.Count; i++)
            {
                //Console.WriteLine(ReqMatch.Groups[i].Value);
            }

            // Приводим ее к изначальному виду, преобразуя экранированные символы
            // Например, "%20" -> " "
            RequestUri = Uri.UnescapeDataString(RequestUri);
            if (RequestUri.IndexOf("..") >= 0)
            {
                SendError(Client, 400);
                return;
            }
            string RequestHead = ReqMatch.Groups[0].Value;
            try
            {
                Work(Client, RequestUri, RequestHead, Request, info, bytes.ToArray());
            }
            catch (Exception ex)
            {
                return;
            }
            Client.Close();
            Client.Dispose();
        }
        public static string GetDir(string pa)
        {
            int p = pa.IndexOf('?');
            if (p > -1)
                return pa.Substring(0, p).Replace("/", "\\");
            else
                return pa.Replace("/", "\\");
        }
        public static string YM = "<!-- Yandex.Metrika counter --> <script type=\"text/javascript\" > (function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter47916812 = new Ya.Metrika2({ id:47916812, clickmap:true, trackLinks:true, accurateTrackBounce:true }); } catch(e) { } }); var n = d.getElementsByTagName(\"script\")[0], s = d.createElement(\"script\"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = \"text/javascript\"; s.async = true; s.src = \"https://mc.yandex.ru/metrika/tag.js\"; if (w.opera == \"[object Opera]\") { d.addEventListener(\"DOMContentLoaded\", f, false); } else { f(); } })(document, window, \"yandex_metrika_callbacks2\"); </script> <noscript><div><img src=\ttps://mc.yandex.ru/watch/47916812\" style=\"position:absolute; left:-9999px;\" alt=\"\" /></div></noscript> <!-- /Yandex.Metrika counter -->";

        public static bool Debug = true;
        public static void ConOut(SynchronizationContext synchronizationContext, string txt)
        {
            if (!Debug)
                return;
            synchronizationContext.Post(new SendOrPostCallback((o) =>
            {
                TextBox textBox = Controls["con"] as TextBox;
                textBox.Text += txt + "\r\n";
                textBox.SelectionStart = textBox.TextLength;
                textBox.ScrollToCaret();
            }), null);
        }
        static void Work(TcpClient Client, string RequestUri, string str, string Request, object obj, byte[] bytes)
        {
            byte[] msg = new byte[0];
            ServerMain Ser = ((InfoToRead)obj).ser;
            Dictionary<string, string> param = new Dictionary<string, string>();
            if (true)
            {
                int length = RSACrypt.GetLength(bytes);
                bytes = bytes.Skip(4).ToArray();
                string SessionID = Encoding.UTF8.GetString(bytes.Take(16).ToArray());
                Session session = Session.GetById(SessionID);
                if (session != null)
                {
                    bytes = bytes.Skip(16).ToArray();
                }
                else
                {
                    ///RSA рукопожатие
                    #region
                    RSACrypt rsa = new RSACrypt();
                    var newses = new Session(Client.Client.RemoteEndPoint.ToString(), rsa);

                    byte expLength = bytes[0];
                    byte[] exponent = new byte[expLength];
                    Buffer.BlockCopy(bytes, 1, exponent, 0, expLength);
                    byte[] modulus = new byte[bytes.Length - (expLength) - 1];
                    Buffer.BlockCopy(bytes, expLength + 1, modulus, 0, modulus.Length);

                    RSAParameters m_ExternKey = new RSAParameters();
                    m_ExternKey.Exponent = exponent;
                    m_ExternKey.Modulus = modulus;
                    rsa.SetExtRSA(m_ExternKey);
                    rsa.Stage = 1;


                    int count = rsa.m_InternKey.Exponent.Length + rsa.m_InternKey.Modulus.Length + 1;
                    msg = new byte[count];
                    msg[0] = (byte)rsa.m_InternKey.Exponent.Length;
                    Array.Copy(rsa.m_InternKey.Exponent, 0, msg, 1, rsa.m_InternKey.Exponent.Length);
                    Array.Copy(rsa.m_InternKey.Modulus, 0, msg, 1 + rsa.m_InternKey.Exponent.Length, rsa.m_InternKey.Modulus.Length);

                    msg = RSACrypt.SetLength(msg);
                    Client.GetStream().Write(msg, 0, msg.Length);

                    rsa.Stage = 3;

                    bytes = GetResponse(Client);
                    string Fcom = rsa.Decrypt(bytes);
                    if (Fcom == "GetID")
                    {
                        msg = rsa.Encrypt(newses.KeyID);
                        msg = RSACrypt.SetLength(msg);
                        Client.GetStream().Write(msg, 0, msg.Length);
                        Session.Sessions.Add(newses.KeyID, newses);
                    }
                    return;
                    #endregion
                }

                string com = session.RSA.Decrypt(bytes);
                ConOut(Ser.synchronization, com);
                var paramLocal = GetParams(com);
                if (paramLocal.ContainsKey("com"))
                {
                    ///Синхронизация времени
                    if (paramLocal["com"] == "gettime")
                    {
                        string msgstr = DateTime.Now.ToFileTime().ToString();
                        SendEncryptedNLog(Client, Ser, session, msgstr);
                        return;
                    }
                    ///Авторизация
                    else if (paramLocal["com"] == "auth")
                    {
                        if (session.User == null)
                        {
                            if (paramLocal.ContainsKey("login") & paramLocal.ContainsKey("pass"))
                            {
                                User user = User.GetByLogin(Form1.Context, paramLocal["login"]);
                                bool valid = user?.CheckPass(paramLocal["pass"]) ?? false;
                                if (valid)
                                {
                                    session.User = user;
                                    var perms = user.GetAllPermisions();
                                    string res = $"res=accept&fio={user.FullName}&loc={user.Location}&permissions=";
                                    for (int i = 0; i < perms.Length; i++)
                                    {
                                        res += perms[i].Name + ",";
                                    }
                                    res = res.Trim(',');
                                    SendEncryptedNLog(Client, Ser, session, res);
                                }
                                else
                                {
                                    string msgstr = "res=denied&message=Неверный логин или пароль";
                                    SendEncryptedNLog(Client, Ser, session, msgstr);
                                }
                            }
                            else
                            {
                                string res = $"res=denied&message=Не хватает обязательных параметров, обновите ПО";
                                res = res.Trim(',');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                        }
                        else
                        {
                            string res = "res=denied&message=Вы уже авторизованны";
                            res = res.Trim(',');
                            SendEncryptedNLog(Client, Ser, session, res);
                        }
                        return;
                    }
                    ///Деавторизация
                    else if(paramLocal["com"] == "unauth")
                    {
                        session.User = null;
                        string res = "res=accept";
                        res = res.Trim(',');
                        SendEncryptedNLog(Client, Ser, session, res);
                    }
                    ///Пинг-понг
                    else if (paramLocal["com"] == "ping")
                    {
                        string res = "pong";
                        res = res.Trim(',');
                        SendEncryptedNLog(Client, Ser, session, res);
                    }
                    if (session.User != null)
                    {
                        if (session.User.CoolDownExpire.ToFileTime() > DateTime.Now.ToFileTime())
                        {
                            //cooldown
                            string res = $"res=denied&message=На вашем аккаунте замечена подозрительная активность, \r\nвы сможете продолжить работу через: " + session.User.CoolDownExpire.Subtract(DateTime.Now).TotalMinutes + " мин.";
                            res = res.Trim(',');
                            SendEncryptedNLog(Client, Ser, session, res);
                            return;
                        }
                        ///Получить все типы задач
                        if (paramLocal["com"] == "gettypes")
                        {
                            var types = TaskType.GetAll(Form1.Context);
                            string res = "res=accept&types=";
                            for (int i = 0; i < types.Length; i++)
                            {
                                res += types[i].Name + ",";
                            }
                            res = res.Trim(',');
                            SendEncryptedNLog(Client, Ser, session, res);
                        }
                        ///Добавление задачи
                        else if (paramLocal["com"] == "addtask")
                        {
                            if (paramLocal.ContainsKey("type") & paramLocal.ContainsKey("desc"))
                            {
                                TaskType taskType = TaskType.GetByName(Form1.Context, paramLocal["type"]);
                                TicketTask ticketTask = new TicketTask(session.User, taskType, paramLocal["desc"]);
                                ticketTask.SetStages();
                                if (taskType == null)
                                {
                                    string res = $"res=accept&id=" + ticketTask.Id + "&message=Задачи такого типа не описанны, ваша задача будет рассмотренна как \"Не типовая\"";
                                    res = res.Trim(',');
                                    SendEncryptedNLog(Client, Ser, session, res);
                                }
                                else
                                {
                                    string res = $"res=accept&id=" + ticketTask.Id + "&message=Вашим вопросом скоро займуться!";
                                    res = res.Trim(',');
                                    SendEncryptedNLog(Client, Ser, session, res);
                                }
                            }
                            else
                            {
                                string res = $"res=denied&message=Не хватает обязательных параметров, обновите ПО";
                                res = res.Trim(',');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                        }
                        ///Получить список всех прав
                        else if (paramLocal["com"] == "getpermissions")
                        {
                            if (session.User.HavePermision(".permissions.view"))
                            {
                                var types = Permision.GetAll(Form1.Context);
                                string res = $"res=accept&";
                                for (int i = 0; i < types.Length; i++)
                                {
                                    res += "nm=" + types[i].Name + "&";
                                    res += "ds=" + types[i].Description + "&";
                                    res += "os=" + (types[i].outside ? 1 : 0).ToString() + "&";
                                }
                                res = res.Trim('&');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        ///Редактировать право
                        else if (paramLocal["com"] == "setpermission")
                        {
                            if (session.User.HavePermision(".permissions.view"))
                            {
                                if (paramLocal.ContainsKey("nm") & paramLocal.ContainsKey("ds") & paramLocal.ContainsKey("os"))
                                {
                                    var perm = Permision.GetByName(Form1.Context, paramLocal["nm"]);
                                    if (perm != null)
                                    {
                                        bool os = paramLocal["os"] == "1" ? true : false;
                                        perm.Description = paramLocal["ds"];
                                        perm.outside = os;
                                        //Form1.ContextSaveChanges();

                                        string res = $"res=accept&nm=" + perm.Name + "&ds=" + perm.Description + "&os=" + (perm.outside ? 1 : 0).ToString();
                                        res = res.Trim('&');
                                        SendEncryptedNLog(Client, Ser, session, res);
                                    }
                                    else
                                    {
                                        string res = $"res=denied&message=Исключение с таким именем не найдено, сервер обновился";
                                        res = res.Trim('&');
                                        SendEncryptedNLog(Client, Ser, session, res);
                                    }
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                }
                            }
                            else
                            {
                                session.User.CoolDownExpire = DateTime.Now.AddMinutes(10);
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        ///Получить список всех ролей
                        else if (paramLocal["com"] == "getroles")
                        {
                            if (session.User.HaveTreePermision(".roles."))
                            {
                                Role[] roles = null;
                                if (session.User.HavePermision(".Roles.ViewDeleted"))
                                    roles = Role.GetAll(Form1.Context, true);
                                else
                                    roles = Role.GetAll(Form1.Context);
                                string res = $"res=accept&";
                                for (int i = 0; i < roles.Length; i++)
                                {
                                    res += "id=" + roles[i].Id + "&";
                                    res += "nm=" + roles[i].Name + "&";
                                    res += "ds=" + roles[i].Description + "&";
                                    res += "isd=" + (roles[i].Deleted ? 1 : 0).ToString() + "&";
                                    res += "isdef=" + (roles[i].isDefault ? 1 : 0).ToString() + "&";
                                    res += "isdefl=" + (roles[i].isLeaderDefaultRole ? 1 : 0).ToString() + "&";
                                    res += "pm=";
                                    for (int j = 0; j < roles[i].Permisions.Count; j++)
                                    {
                                        res += roles[i].Permisions[j].Name + ",";
                                    }
                                    res = res.Trim(',');
                                    res += "&";
                                }
                                res = res.Trim('&').Trim(',');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        ///Добавить роле
                        else if (paramLocal["com"] == "addrole")
                        {
                            if (paramLocal.ContainsKey("nm"))
                            {
                                if (session.User.HavePermision(".roles.add"))
                                {
                                    Role role = Role.GetByName(Form1.Context, paramLocal["nm"], true);
                                    if (role == null)
                                    {
                                        role = new Role();
                                        role.Name = paramLocal["nm"];
                                        // Form1.ContextRoles.Add(role);
                                        // Form1.ContextSaveChanges();

                                        string res = $"res=accept&";
                                        res += "id=" + role.Id + "&";
                                        res += "nm=" + role.Name + "&";
                                        res += "ds=" + role.Description + "&";
                                        res += "isd=" + (role.Deleted ? 1 : 0).ToString() + "&";
                                        res += "isdef=" + (role.isDefault ? 1 : 0).ToString() + "&";
                                        res += "isdefl=" + (role.isLeaderDefaultRole ? 1 : 0).ToString() + "&";
                                        res += "pm=";
                                        for (int j = 0; j < role.Permisions.Count; j++)
                                        {
                                            res += role.Permisions[j].Name + ",";
                                        }
                                        res = res.Trim(',');
                                        SendEncryptedNLog(Client, Ser, session, res);
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "res=denied&message=Роль с таким названием уже есть");
                                    }
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{1}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                            }
                        }
                        //Редактирование роли
                        else if (paramLocal["com"] == "setrole")
                        {
                            if (session.User.HaveTreePermision(".roles."))
                            {
                                if (paramLocal.ContainsKey("id"))
                                {
                                    if (paramLocal.ContainsKey("nm"))
                                    {
                                        Role role = null;
                                        if (session.User.HavePermision(".Roles.ViewDeleted"))
                                            role = Role.GetByName(Form1.Context, paramLocal["nm"], true);
                                        else
                                            role = Role.GetByName(Form1.Context, paramLocal["nm"]);
                                        if (role != null)
                                        {
                                            if (role.Id.ToString() == paramLocal["id"])
                                            {
                                                if (paramLocal.ContainsKey("nnm"))
                                                {
                                                    if (session.User.HavePermision(".roles.name.edit"))
                                                        role.Name = paramLocal["nnm"];
                                                }
                                                if (paramLocal.ContainsKey("ds"))
                                                {
                                                    if (session.User.HavePermision(".roles.description.edit"))
                                                        role.Description = paramLocal["ds"];
                                                }
                                                if (paramLocal.ContainsKey("isd"))
                                                {
                                                    bool isd = paramLocal["isd"] == "1" ? true : false;
                                                    if (isd & session.User.HavePermision(".roles.delete") ||
                                                        !isd & session.User.HavePermision(".roles.recover"))
                                                        role.Deleted = isd;
                                                }
                                                if (paramLocal.ContainsKey("isdef"))
                                                {
                                                    bool isd = paramLocal["isdef"] == "1" ? true : false;
                                                    if (isd & session.User.HavePermision(".roles.isdefault.edit"))
                                                    {
                                                        role.isDefault = isd;
                                                        if (role.isDefault)
                                                        {
                                                            foreach (var tt in Role.Roles)
                                                                if (tt != role) tt.isDefault = false;
                                                        }
                                                    }
                                                }
                                                if (paramLocal.ContainsKey("isdefl"))
                                                {
                                                    bool isd = paramLocal["isdefl"] == "1" ? true : false;
                                                    if (isd & session.User.HavePermision(".roles.isdefaultleader.edit"))
                                                    {
                                                        role.isLeaderDefaultRole = isd;
                                                        if (role.isLeaderDefaultRole)
                                                        {
                                                            foreach (var tt in Role.Roles)
                                                                if (tt != role) tt.isLeaderDefaultRole = false;
                                                        }
                                                    }
                                                }
                                                if (paramLocal.ContainsKey("pma"))
                                                {
                                                    if (session.User.HavePermision(".roles.permissions.add"))
                                                    {
                                                        string[] perms = paramLocal["pma"].Split(',');
                                                        for (int i = 0; i < perms.Length; i++)
                                                        {
                                                            Permision permision = Permision.GetByName(Form1.Context, perms[i]);
                                                            if (permision != null)
                                                                if (!role.Permisions.Contains(permision))
                                                                {
                                                                    role.Permisions.Add(permision);
                                                                }
                                                        }
                                                    }
                                                }
                                                if (paramLocal.ContainsKey("pmd"))
                                                {
                                                    if (session.User.HavePermision(".roles.permissions.delete"))
                                                    {
                                                        string[] perms = paramLocal["pmd"].Split(',');
                                                        for (int i = 0; i < perms.Length; i++)
                                                        {
                                                            Permision permision = Permision.GetByName(Form1.Context, perms[i]);
                                                            if (permision != null)
                                                                if (role.Permisions.Contains(permision))
                                                                {
                                                                    role.Permisions.Remove(permision);
                                                                }
                                                        }
                                                    }
                                                }
                                                //Form1.ContextSaveChanges();

                                                string res = $"res=accept&id=" + role.Id + "&nm=" + role.Name + "&ds=" + role.Description + "&isd=" + (role.Deleted ? 1 : 0) + "&isdef=" + (role.isDefault ? 1 : 0) + "&isdefl=" + (role.isLeaderDefaultRole ? 1 : 0) + "&pm=";
                                                for (int j = 0; j < role.Permisions.Count; j++)
                                                {
                                                    res += role.Permisions[j].Name + ",";
                                                }
                                                res = res.Trim(',');
                                                SendEncryptedNLog(Client, Ser, session, res);
                                            }
                                        }
                                        else
                                        {
                                            string res = $"res=denied&message=Роль не найдена";
                                            SendEncryptedNLog(Client, Ser, session, res);
                                        }
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "{2}");
                                    }
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Поиск по разрешениям
                        else if (paramLocal["com"] == "searchpermissions")
                        {
                            if (session.User.HavePermision(".permissions.view"))
                            {
                                if (paramLocal.ContainsKey("line"))
                                {
                                    var searchres = Permision.GetTreeByName(Form1.Context, paramLocal["line"]);
                                    string res = $"res=accept&searchres=";
                                    for (int i = 0; i < searchres.Length; i++)
                                    {
                                        res += searchres[i].Name + ",";
                                    }
                                    res = res.Trim(',');
                                    SendEncryptedNLog(Client, Ser, session, res);
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Полнотекстовый поиск ролей
                        else if (paramLocal["com"] == "searchroles")
                        {
                            if (session.User.HaveTreePermision(".roles."))
                            {
                                Role[] roles = null;
                                if (paramLocal.ContainsKey("line"))
                                {
                                    /*if (session.User.HavePermision(".roles.ViewDeleted"))
                                        roles = Role.SearchByText(Form1.Context, paramLocal["line"], true);
                                    else*/
                                    roles = Role.SearchByText(Form1.Context, paramLocal["line"], false);
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                    return;
                                }
                                int offsetPage = 0;
                                int PageLength = 50;
                                if (paramLocal.ContainsKey("offset") & paramLocal.ContainsKey("length"))
                                {
                                    int.TryParse(paramLocal["offset"], out offsetPage);
                                    int.TryParse(paramLocal["length"], out PageLength);
                                }
                                offsetPage = --offsetPage < 0 ? 0 : offsetPage;
                                roles = roles.Skip(offsetPage * PageLength).Take(PageLength).ToArray();
                                string res = $"res=accept&searchres=";
                                for (int i = 0; i < roles.Length; i++)
                                {
                                    res += roles[i].Name + ",";
                                }
                                res = res.Trim(',');
                                if (roles.Length != 0)
                                    res = res.Trim('&');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Полнотекстовый поиск этапов
                        else if (paramLocal["com"] == "searchstages")
                        {
                            if (session.User.HavePermision(".stages.view"))
                            {
                                TaskStage[] stages = null;
                                if (paramLocal.ContainsKey("line"))
                                {
                                    stages = TaskStage.SearchByText(Form1.Context, paramLocal["line"], session.User.HavePermision(".stages.ViewDeleted"));
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                    return;
                                }
                                bool full = false;
                                if (paramLocal.ContainsKey("info"))
                                {
                                    if (paramLocal["info"] == "1")
                                        full = true;
                                }
                                int offsetPage = 0;
                                int PageLength = 50;
                                if (paramLocal.ContainsKey("offset") & paramLocal.ContainsKey("length"))
                                {
                                    int.TryParse(paramLocal["offset"], out offsetPage);
                                    int.TryParse(paramLocal["length"], out PageLength);
                                }
                                offsetPage = --offsetPage < 0 ? 0 : offsetPage;
                                stages = stages.Skip(offsetPage * PageLength).Take(PageLength).ToArray();
                                string res = "";
                                if (full)
                                {
                                    res = "res=accept&";
                                    for (int i = 0; i < stages.Length; i++)
                                    {
                                        res += "id=" + stages[i].Id + "&";
                                        res += "nm=" + stages[i].Name + "&";
                                        res += "isd=" + (stages[i].Deleted ? 1 : 0).ToString() + "&";
                                        res += "ds=" + stages[i].Description + "&";
                                        res += "ap=" + (stages[i].AutoPick ? 1 : 0).ToString() + "&";
                                        res += "sla=" + stages[i].SLAminute + "&";
                                        res += "rl=";
                                        for (int j = 0; j < stages[i].Roles.Count; j++)
                                        {
                                            res += stages[i].Roles[j].Name + ",";
                                        }
                                        res = res.Trim(',');
                                        res += "&";
                                    }
                                }
                                else
                                {
                                    res = "res=";
                                    for (int i = 0; i < stages.Length; i++)
                                    {
                                        res += stages[i].Name + ",";
                                    }
                                }
                                res = res.Trim(',');
                                if (stages.Length != 0)
                                    res = res.Trim('&');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Полнотекстовый поиск пользователей, а так же поиск по логину
                        else if (paramLocal["com"] == "searchusers")
                        {
                            if (paramLocal.ContainsKey("offset") & paramLocal.ContainsKey("length"))
                            {
                                if (session.User.HavePermision(".users.view"))
                                {
                                    User[] users = null;
                                    if (paramLocal.ContainsKey("line"))
                                    {
                                        if (session.User.HavePermision(".Users.ViewDeleted"))
                                            users = User.SearchByText(Form1.Context, paramLocal["line"], true);
                                        else
                                            users = User.SearchByText(Form1.Context, paramLocal["line"], false);
                                    }
                                    else if (paramLocal.ContainsKey("login"))
                                    {
                                        if (session.User.HavePermision(".Users.ViewDeleted"))
                                            users = User.SearchByLogin(Form1.Context, paramLocal["login"], true);
                                        else
                                            users = User.SearchByLogin(Form1.Context, paramLocal["login"], false);
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "{2}");
                                        return;
                                    }
                                    int offsetPage = 0;
                                    int PageLength = 50;
                                    int.TryParse(paramLocal["offset"], out offsetPage);
                                    int.TryParse(paramLocal["length"], out PageLength);
                                    offsetPage = --offsetPage < 0 ? 0 : offsetPage;
                                    users = users.Skip(offsetPage * PageLength).Take(PageLength).ToArray();
                                    string res = $"res=accept&";
                                    for (int i = 0; i < users.Length; i++)
                                    {
                                        res += "id=" + users[i].Id + "&";
                                        res += "lg=" + users[i].Login + "&";
                                        res += "isd=" + (users[i].Deleted ? 1 : 0).ToString() + "&";
                                        res += "fn=" + users[i].FullName + "&";
                                        res += "ll=" + users[i].LoginOfLeader + "&";
                                        res += "dr=" + users[i].RegDate.DateToString() + "&";
                                        res += "isb=" + (users[i].Blocked ? 1 : 0).ToString() + "&";
                                        res += "isbit=" + (users[i].BlockedInTasks ? 1 : 0).ToString() + "&";
                                        res += "isbcd=" + (users[i].CoolDownExpire.Subtract(DateTime.Now).TotalMinutes > 0 ? 1 : 0).ToString() + "&";
                                        res += "lc=" + users[i].Location + "&";
                                        res += "lc=" + users[i].SLALast + "&";
                                        res += "rl=";
                                        for (int j = 0; j < users[i].Roles.Count; j++)
                                        {
                                            res += users[i].Roles[j].Name + ",";
                                        }
                                        res = res.Trim(',');
                                        res += "&";

                                        res += "rpm=";
                                        for (int j = 0; j < users[i].Restricted.Count; j++)
                                        {
                                            res += users[i].Restricted[j].Name + ",";
                                        }
                                        res = res.Trim(',');
                                        res += "&";
                                    }
                                    if (users.Length != 0)
                                        res = res.Trim('&');
                                    SendEncryptedNLog(Client, Ser, session, res);
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{1}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                            }
                        }
                        //Выдает пользователя по точному логину
                        else if (paramLocal["com"] == "getuserbylogin")
                        {
                            if (paramLocal.ContainsKey("login"))
                            {
                                User user = null;
                                if (session.User.HavePermision(".Users.ViewDeleted"))
                                    user = User.GetByLogin(Form1.Context, paramLocal["login"], true);
                                else
                                    user = User.GetByLogin(Form1.Context, paramLocal["login"]);
                                if (user != null)
                                {
                                    string res = "res=accept&";
                                    res += "id=" + user.Id + "&";
                                    res += "lg=" + user.Login + "&";
                                    res += "isd=" + (user.Deleted ? 1 : 0).ToString() + "&";
                                    res += "fn=" + user.FullName + "&";
                                    res += "ll=" + user.LoginOfLeader + "&";
                                    res += "dr=" + user.RegDate.DateToString() + "&";
                                    res += "isb=" + (user.Blocked ? 1 : 0).ToString() + "&";
                                    res += "isbit=" + (user.BlockedInTasks ? 1 : 0).ToString() + "&";
                                    res += "isbcd=" + (user.CoolDownExpire.Subtract(DateTime.Now).TotalMinutes > 0 ? 1 : 0).ToString() + "&";
                                    res += "lc=" + user.Location + "&";
                                    res += "sla=" + user.SLALast + "&";
                                    res += "rl=";
                                    for (int j = 0; j < user.Roles.Count; j++)
                                    {
                                        res += user.Roles[j].Name + ",";
                                    }
                                    res = res.Trim(',');
                                    res += "&";

                                    res += "rpm=";
                                    for (int j = 0; j < user.Restricted.Count; j++)
                                    {
                                        res += user.Restricted[j].Name + ",";
                                    }
                                    res = res.Trim(',');
                                    SendEncryptedNLog(Client, Ser, session, res);
                                }
                            }
                        }
                        //Добавляет пользователя
                        else if (paramLocal["com"] == "adduser")
                        {
                            if (session.User.HavePermision(".users.add"))
                            {
                                User user = new User();
                                while (true)
                                {
                                    string login = Cryptographi.GetRandom(8);
                                    if (User.GetByLogin(Form1.Context, login) == null)
                                    {
                                        user.Login = login;
                                        break;
                                    }
                                }
                                user.SavePass(Cryptographi.GetSHA512("12345678"));
                                User defaultUser = User.GetByLogin(Form1.Context, "default");
                                user.RegDate = DateTime.Now;
                                if (defaultUser != null)
                                {
                                    user.Location = defaultUser.Location;
                                    user.Blocked = defaultUser.Blocked;
                                    user.BlockedInTasks = defaultUser.BlockedInTasks;
                                    user.FullName = defaultUser.FullName;
                                    user.LoginOfLeader = defaultUser.LoginOfLeader;
                                    user.Notifis = defaultUser.Notifis;

                                    Permision[] restricted = new Permision[defaultUser.Restricted.Count];
                                    defaultUser.Restricted.CopyTo(restricted);
                                    user.Restricted.AddRange(restricted);

                                    Role[] roles = new Role[defaultUser.Roles.Count];
                                    defaultUser.Roles.CopyTo(roles);
                                    user.Roles.AddRange(roles);
                                }
                                Role role = Role.GetByName(Form1.Context);
                                if (role != null)
                                {
                                    user.Roles.Add(role);
                                }
                                string res = "res=accept&";
                                res += "id=" + user.Id + "&";
                                res += "lg=" + user.Login + "&";
                                res += "isd=" + (user.Deleted ? 1 : 0).ToString() + "&";
                                res += "fn=" + user.FullName + "&";
                                res += "ll=" + user.LoginOfLeader + "&";
                                res += "dr=" + user.RegDate.DateToString() + "&";
                                res += "isb=" + (user.Blocked ? 1 : 0).ToString() + "&";
                                res += "isbit=" + (user.BlockedInTasks ? 1 : 0).ToString() + "&";
                                res += "isbcd=" + (user.CoolDownExpire.Subtract(DateTime.Now).TotalMinutes > 0 ? 1 : 0).ToString() + "&";
                                res += "lc=" + user.Location + "&";
                                res += "sla=" + user.SLALast + "&";
                                res += "rl=";
                                for (int j = 0; j < user.Roles.Count; j++)
                                {
                                    res += user.Roles[j].Name + ",";
                                }
                                res = res.Trim(',');
                                res += "&";

                                res += "rpm=";
                                for (int j = 0; j < user.Restricted.Count; j++)
                                {
                                    res += user.Restricted[j].Name + ",";
                                }
                                res = res.Trim(',');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                        }
                        //Изменяет пароль пользователя
                        else if (paramLocal["com"] == "setuserpass")
                        {
                            if (session.User.HaveTreePermision(".users.pass.edit"))
                            {
                                if (paramLocal.ContainsKey("lg") & paramLocal.ContainsKey("ph"))
                                {
                                    User user = User.GetByLogin(Form1.Context, paramLocal["lg"], session.User.HavePermision(".Users.ViewDeleted"));
                                    if (user != null)
                                    {
                                        user.SavePass(paramLocal["ph"]);
                                        SendEncryptedNLog(Client, Ser, session, "res=accept");
                                    }
                                    else
                                        SendEncryptedNLog(Client, Ser, session, "res=denied&message=Пользователь не найден");
                                }
                                else
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                            }
                            else
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                        }
                        //Изменяет пользователя
                        else if (paramLocal["com"] == "setuser")
                        {
                            if (session.User.HaveTreePermision(".users."))
                            {
                                if (paramLocal.ContainsKey("id"))
                                {
                                    if (paramLocal.ContainsKey("lg"))
                                    {
                                        User user = null;
                                        if (session.User.HavePermision(".Users.ViewDeleted"))
                                            user = User.GetByLogin(Form1.Context, paramLocal["lg"], true);
                                        else
                                            user = User.GetByLogin(Form1.Context, paramLocal["lg"]);
                                        if (user != null)
                                        {
                                            if (user.Id.ToString() == paramLocal["id"])
                                            {
                                                if (paramLocal.ContainsKey("nlg"))
                                                {
                                                    if (session.User.HavePermision(".users.login.edit"))
                                                        user.Login = paramLocal["nlg"];
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("fn"))
                                                {
                                                    if (session.User.HavePermision(".users.fullname.edit"))
                                                        user.FullName = paramLocal["fn"];
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("ll"))
                                                {
                                                    if (session.User.HavePermision(".users.LoginOfLeader.edit"))
                                                        user.LoginOfLeader = paramLocal["ll"];
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("lc"))
                                                {
                                                    if (session.User.HavePermision(".users.Location.edit"))
                                                        user.Location = paramLocal["lc"];
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("isb"))
                                                {
                                                    bool isd = paramLocal["isb"] == "1" ? true : false;
                                                    if (isd & session.User.HavePermision(".users.Block.set") ||
                                                        !isd & session.User.HavePermision(".users.Block.delete"))
                                                        user.Blocked = isd;
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("isbit"))
                                                {
                                                    bool isd = paramLocal["isbit"] == "1" ? true : false;
                                                    if (isd & session.User.HavePermision(".users.BlockInTasks.set") ||
                                                        !isd & session.User.HavePermision(".users.BlockInTasks.delete"))
                                                        user.BlockedInTasks = isd;
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("isd"))
                                                {
                                                    bool isd = paramLocal["isd"] == "1" ? true : false;
                                                    if (isd & session.User.HavePermision(".users.delete") ||
                                                        !isd & session.User.HavePermision(".users.recover"))
                                                        user.Deleted = isd;
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("pma"))
                                                {
                                                    if (session.User.HavePermision(".users.restricted.add"))
                                                    {
                                                        string[] perms = paramLocal["pma"].Split(',');
                                                        for (int i = 0; i < perms.Length; i++)
                                                        {
                                                            Permision permision = Permision.GetByName(Form1.Context, perms[i]);
                                                            if (permision != null)
                                                                if (!user.Restricted.Contains(permision))
                                                                    user.Restricted.Add(permision);
                                                        }
                                                    }
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("pmd"))
                                                {
                                                    if (session.User.HavePermision(".users.restricted.delete"))
                                                    {
                                                        string[] perms = paramLocal["pmd"].Split(',');
                                                        for (int i = 0; i < perms.Length; i++)
                                                        {
                                                            Permision permision = Permision.GetByName(Form1.Context, perms[i]);
                                                            if (permision != null)
                                                                if (user.Restricted.Contains(permision))
                                                                    user.Restricted.Remove(permision);
                                                        }
                                                    }
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }

                                                if (paramLocal.ContainsKey("rla"))
                                                {
                                                    if (session.User.HavePermision(".users.roles.add"))
                                                    {
                                                        string[] perms = paramLocal["rla"].Split(',');
                                                        for (int i = 0; i < perms.Length; i++)
                                                        {
                                                            Role role = Role.GetByName(Form1.Context, perms[i]);
                                                            if (role != null)
                                                                if (!user.Roles.Contains(role))
                                                                    user.Roles.Add(role);
                                                        }
                                                    }
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                if (paramLocal.ContainsKey("rld"))
                                                {
                                                    if (session.User.HavePermision(".users.roles.delete"))
                                                    {
                                                        string[] perms = paramLocal["rld"].Split(',');
                                                        for (int i = 0; i < perms.Length; i++)
                                                        {
                                                            Role role = Role.GetByName(Form1.Context, perms[i]);
                                                            if (role != null)
                                                                if (user.Roles.Contains(role))
                                                                    user.Roles.Remove(role);
                                                        }
                                                    }
                                                    else
                                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                                //Form1.ContextSaveChanges();

                                                string res = $"res=accept&lg=" + user.Login;
                                                SendEncryptedNLog(Client, Ser, session, res);
                                            }
                                            else
                                            {
                                                string res = $"res=denied&message=Роль не найдена, кто-то уже внес изменения";
                                                SendEncryptedNLog(Client, Ser, session, res);
                                            }
                                        }
                                        else
                                        {
                                            string res = $"res=denied&message=Пользователь не найден";
                                            SendEncryptedNLog(Client, Ser, session, res);
                                        }
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "{2}");
                                    }
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Отменяет временную блокировку
                        else if (paramLocal["com"] == "usercdreset")
                        {
                            if (session.User.HaveTreePermision(".users."))
                            {
                                if (paramLocal.ContainsKey("id"))
                                {
                                    if (paramLocal.ContainsKey("lg"))
                                    {
                                        User user = null;
                                        if (session.User.HavePermision(".Users.ViewDeleted"))
                                            user = User.GetByLogin(Form1.Context, paramLocal["lg"], true);
                                        else
                                            user = User.GetByLogin(Form1.Context, paramLocal["lg"]);
                                        if (user != null)
                                        {
                                            if (user.Id.ToString() == paramLocal["id"])
                                            {
                                                if (session.User.HavePermision(".Users.CoolDown.Delete"))
                                                {
                                                    user.CoolDownExpire = DateTime.Now;
                                                    //Form1.ContextSaveChanges();
                                                    string res = $"res=accept";
                                                    SendEncryptedNLog(Client, Ser, session, res);
                                                }
                                                else
                                                {
                                                    SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                            }
                                            else
                                            {
                                                string res = $"res=denied&message=Роль не найдена, кто-то уже внес изменения";
                                                SendEncryptedNLog(Client, Ser, session, res);
                                            }
                                        }
                                        else
                                        {
                                            string res = $"res=denied&message=Пользователь не найден";
                                            SendEncryptedNLog(Client, Ser, session, res);
                                        }
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "{2}");
                                    }
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Получить задачи
                        else if (paramLocal["com"] == "gettickets")
                        {
                            if (session.User.HavePermision(".tickets.view") | true)
                            {
                                List<TicketTask> tickets = new List<TicketTask>();
                                string line = "";
                                if (paramLocal.ContainsKey("line"))
                                    line = paramLocal["line"];
                                tickets = TicketTask.SearchByText(Form1.Context, line, session.User.HavePermision(".tickets.ViewDeleted"), session.User.HavePermision(".tickets.closed.View")).ToList();
                                for (int i = 0; i < tickets.Count; i++)
                                {
                                    if (!tickets[i].CheckVisibilityForUser(session.User, null))
                                    {
                                        tickets.RemoveAt(i);
                                        i--;
                                    }
                                }
                                int offsetPage = 0;
                                int PageLength = 50;
                                if (paramLocal.ContainsKey("offset") & paramLocal.ContainsKey("length"))
                                {
                                    int.TryParse(paramLocal["offset"], out offsetPage);
                                    int.TryParse(paramLocal["length"], out PageLength);
                                }
                                offsetPage = --offsetPage < 0 ? 0 : offsetPage;
                                tickets = tickets.Skip(offsetPage * PageLength).Take(PageLength).ToList();
                                string res = $"res=accept&";
                                for (int i = 0; i < tickets.Count; i++)
                                {
                                    res += "id=" + tickets[i].Id + "&";
                                    res += "snl=" + tickets[i].Sender.Login + "&";
                                    res += "snn=" + tickets[i].Sender.FullName + "&";
                                    res += "snll=" + tickets[i].Sender.LoginOfLeader + "&";
                                    res += "ty=" + tickets[i].Type.Name + "&";
                                    res += "rd=" + tickets[i].ReqDate.DateToString() + "&";
                                    res += "pr=" + tickets[i].Priority + "&";
                                    res += "isd=" + (tickets[i].Deleted ? "1" : "0") + "&";
                                    res += "isc=" + (tickets[i].Closed ? "1" : "0") + "&";
                                    res += "cm=" + tickets[i].Comments + "&";

                                    res += "ags=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        res += tickets[i].Agreements[n].TaskStage.Name + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "agr=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        res += (tickets[i].Agreements[n].Sender?.Login ?? " ") + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "agv=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        res += (tickets[i].Agreements[n].Visor?.Login ?? " ") + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "agc=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        res += (tickets[i].Agreements[n].Checked ? "1" : "0") + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "aga=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        res += (tickets[i].Agreements[n].Aproove ? "1" : "0") + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "agd=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        res += tickets[i].Agreements[n].DateOfReq.DateToString() + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "agda=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        res += tickets[i].Agreements[n].DateOfApprove.DateToString() + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "agsl=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        res += tickets[i].Agreements[n].TaskStage.SLAminute + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "agls=";
                                    for (int n = 0; n < tickets[i].Agreements.Count; n++)
                                    {
                                        if (tickets[i].Agreements[n].Checked)
                                            res += Math.Floor(tickets[i].Agreements[n].DateOfApprove.Subtract(tickets[i].Agreements[n].DateOfReq).TotalMinutes) + ",";
                                        else
                                            res += Math.Floor(tickets[i].Agreements[n].TaskStage.SLAminute - DateTime.Now.Subtract(tickets[i].Agreements[n].DateOfReq).TotalMinutes) + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "tu=";
                                    for (int n = 0; n < tickets[i].TaskUpdates.Count; n++)
                                    {
                                        res += tickets[i].TaskUpdates[n].TimeStamp.DateToString() + " - " + tickets[i].TaskUpdates[n].UpdateString + ",";
                                    }
                                    res = res.Trim(',') + "&";

                                    res += "ts=";
                                    for (int n = 0; n < tickets[i].Stages.Count; n++)
                                    {
                                        res += tickets[i].Stages[n].Name + ",";
                                    }
                                    res = res.Trim(',') + "&";
                                }
                                if (tickets.Count != 0)
                                    res = res.Trim('&');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Обновить задачу
                        else if (paramLocal["com"] == "getticket")
                        {
                            if (true)
                            {
                                TicketTask ticket = null;
                                string line = "";
                                if (paramLocal.ContainsKey("id"))
                                    line = paramLocal["id"];
                                if (session.User.HavePermision(".tickets.ViewDeleted"))
                                    ticket = TicketTask.GetById(Form1.Context, int.Parse(line), true);
                                else
                                    ticket = TicketTask.GetById(Form1.Context, int.Parse(line), false);
                                string res = $"res=accept&";
                                res += "id=" + ticket.Id + "&";
                                res += "snl=" + ticket.Sender.Login + "&";
                                res += "snn=" + ticket.Sender.FullName + "&";
                                res += "snll=" + ticket.Sender.LoginOfLeader + "&";
                                res += "ty=" + ticket.Type.Name + "&";
                                res += "rd=" + ticket.ReqDate.DateToString() + "&";
                                res += "pr=" + ticket.Priority + "&";
                                res += "isd=" + (ticket.Deleted ? "1" : "0") + "&";
                                res += "isc=" + (ticket.Closed ? "1" : "0") + "&";
                                res += "cm=" + ticket.Comments + "&";

                                res += "ags=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    res += ticket.Agreements[n].TaskStage.Name + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "agr=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    res += (ticket.Agreements[n].Sender?.Login ?? " ") + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "agv=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    res += (ticket.Agreements[n].Visor?.Login ?? " ") + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "agc=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    res += (ticket.Agreements[n].Checked ? "1" : "0") + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "aga=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    res += (ticket.Agreements[n].Aproove ? "1" : "0") + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "agd=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    res += ticket.Agreements[n].DateOfReq.DateToString() + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "agda=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    res += ticket.Agreements[n].DateOfApprove.DateToString() + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "agsl=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    res += ticket.Agreements[n].TaskStage.SLAminute + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "agls=";
                                for (int n = 0; n < ticket.Agreements.Count; n++)
                                {
                                    if (ticket.Agreements[n].Checked)
                                        res += Math.Floor(ticket.Agreements[n].DateOfApprove.Subtract(ticket.Agreements[n].DateOfReq).TotalMinutes) + ",";
                                    else
                                        res += Math.Floor(ticket.Agreements[n].TaskStage.SLAminute - DateTime.Now.Subtract(ticket.Agreements[n].DateOfReq).TotalMinutes) + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "tu=";
                                for (int n = 0; n < ticket.TaskUpdates.Count; n++)
                                {
                                    res += ticket.TaskUpdates[n].TimeStamp.DateToString() + " - " + ticket.TaskUpdates[n].UpdateString + ",";
                                }
                                res = res.Trim(',') + "&";

                                res += "ts=";
                                for (int n = 0; n < ticket.Stages.Count; n++)
                                {
                                    res += ticket.Stages[n].Name + ",";
                                }
                                res = res.Trim(',') + "&";

                                res = res.Trim('&');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Удалить согласование
                        else if (paramLocal["com"] == "agreeremove")
                        {
                            if (session.User.HavePermision(".Agreements.Delete"))
                            {
                                if (paramLocal.ContainsKey("id") & paramLocal.ContainsKey("stage"))
                                {
                                    bool tr = false;
                                    TicketTask task = TicketTask.GetById(null, int.Parse(paramLocal["id"]));
                                    for (int i = task.Agreements.Count - 1; i >= 0; i--)
                                    {
                                        if (task.Agreements[i].TaskStage.Name == paramLocal["stage"])
                                        {
                                            if (task.Agreements[i].Checked == false)
                                            {
                                                task.Agreements.RemoveAt(i);
                                                tr = true;
                                                task.TaskUpdates.Add(new TaskUpdates(session.User.ToString() + " удалил согласование " + task.Agreements[i].TaskStage.Name));
                                                break;
                                            }
                                        }
                                    }
                                    if (tr)
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "res=accept");
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "res=denied&message=Отсутствует согласование этапа " + paramLocal["stage"] + ", которое можно удалить");
                                    }
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Сбросить сорласование
                        else if (paramLocal["com"] == "agreereset")
                        {
                            if (session.User.HavePermision(".Agreements.Reset"))
                            {
                                if (paramLocal.ContainsKey("id") & paramLocal.ContainsKey("stage"))
                                {
                                    bool tr = false;
                                    TicketTask task = TicketTask.GetById(null, int.Parse(paramLocal["id"]));
                                    for (int i = task.Agreements.Count - 1; i >= 0; i--)
                                    {
                                        if (task.Agreements[i].TaskStage.Name == paramLocal["stage"])
                                        {
                                            if (task.Agreements[i].Checked == true)
                                            {
                                                if (task.CheckSpaceToAddAgree(task.Agreements[i].TaskStage))
                                                {
                                                    string from = task.Agreements[i].Visor?.ToString() == null ? "от " + task.Agreements[i].Visor?.ToString() : "";
                                                    string result = task.Agreements[i].Aproove ? "Положительное" : "Отрицательное";
                                                    task.TaskUpdates.Add(new TaskUpdates(session.User.ToString() + " сбросил " + result + " согласование " + task.Agreements[i].TaskStage.Name + from));
                                                    task.Agreements[i].Checked = false;
                                                    task.Agreements[i].Visor = null;
                                                    tr = true;
                                                }
                                                break;
                                            }
                                        }
                                    }
                                    if (tr)
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "res=accept");
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "res=denied&message=Отсутствует согласование этапа " + paramLocal["stage"] + ", которое можно сбросить");
                                    }
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Перезапросить согласование
                        else if (paramLocal["com"] == "agreererequest")
                        {
                            if (session.User.HavePermision(".Agreements.ReRequest"))
                            {
                                if (paramLocal.ContainsKey("id") & paramLocal.ContainsKey("stage"))
                                {
                                    bool tr = false;
                                    TicketTask task = TicketTask.GetById(null, int.Parse(paramLocal["id"]));
                                    for (int i = task.Agreements.Count - 1; i >= 0; i--)
                                    {
                                        if (task.Agreements[i].TaskStage.Name == paramLocal["stage"])
                                        {
                                            if (task.Agreements[i].Checked == true)
                                            {
                                                if (task.CheckSpaceToAddAgree(task.Agreements[i].TaskStage))
                                                {
                                                    Agreement item = new Agreement(task.Agreements[i].TaskStage);
                                                    string from = task.Agreements[i].Visor?.ToString() == null ? "от " + task.Agreements[i].Visor?.ToString() : "";
                                                    string result = task.Agreements[i].Aproove ? "Положительное" : "Отрицательное";
                                                    task.TaskUpdates.Add(new TaskUpdates(session.User.ToString() + " перезапросил " + result + " согласование " + task.Agreements[i].TaskStage.Name + from));
                                                    item.Visor = task.Agreements[i].Visor;
                                                    task.Agreements.Add(item);
                                                    tr = true;
                                                }
                                                break;
                                            }
                                        }
                                    }
                                    if (tr)
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "res=accept");
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "res=denied&message=Отсутствует согласование этапа " + paramLocal["stage"] + ", которое можно перезапросить");
                                    }
                                }
                                else
                                {
                                    SendEncryptedNLog(Client, Ser, session, "{2}");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        //Сохранить этапы
                        else if (paramLocal["com"] == "savestages")
                        {
                            if (paramLocal.ContainsKey("id"))
                            {
                                TicketTask task = TicketTask.GetById(null, int.Parse(paramLocal["id"]), session.User.HavePermision(".Tickets.ViewDeleted"));
                                if (task == null)
                                {
                                    SendEncryptedNLog(Client, Ser, session, "res=denied&message=Задача не найдена");
                                }
                                else
                                {
                                    if (paramLocal.ContainsKey("sa"))
                                    {
                                        if (session.User.HavePermision(".Tickets.Stages.Add"))
                                        {
                                            string[] perms = paramLocal["sa"].Split(',');
                                            for (int i = 0; i < perms.Length; i++)
                                            {
                                                TaskStage taskStage = TaskStage.GetByName(Form1.Context, perms[i]);
                                                if (taskStage != null)
                                                {
                                                    task.TaskUpdates.Add(new TaskUpdates(session.User.ToString() + " добавил этап " + taskStage.Name));
                                                    task.Stages.Add(taskStage);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            SendEncryptedNLog(Client, Ser, session, "{1}");
                                        }
                                    }
                                    if (paramLocal.ContainsKey("sd"))
                                    {
                                        if (session.User.HavePermision(".Tickets.Stages.Delete"))
                                        {
                                            string[] perms = paramLocal["sd"].Split(',');
                                            for (int i = 0; i < perms.Length; i++)
                                            {
                                                TaskStage taskStage = TaskStage.GetByName(Form1.Context, perms[i]);
                                                if (taskStage != null)
                                                    if (task.Stages.Contains(taskStage))
                                                    {
                                                        task.TaskUpdates.Add(new TaskUpdates(session.User.ToString() + " удалил этап " + taskStage.Name));
                                                        task.Stages.Remove(taskStage);
                                                    }
                                            }
                                        }
                                        else
                                        {
                                            SendEncryptedNLog(Client, Ser, session, "{1}");
                                        }
                                    }
                                    SendEncryptedNLog(Client, Ser, session, "res=accept");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                            }
                        }
                        //Согласование
                        else if (paramLocal["com"] == "setagree")
                        {
                            if (paramLocal.ContainsKey("id") & paramLocal.ContainsKey("aproove") & paramLocal.ContainsKey("move"))
                            {
                                TicketTask task = TicketTask.GetById(null, int.Parse(paramLocal["id"]), false);
                                if (task == null)
                                {
                                    SendEncryptedNLog(Client, Ser, session, "res=denied&message=Задача не найдена");
                                }
                                else
                                {
                                    if (true)
                                    {
                                        if (task.CheckVisibilityForUser(session.User, null))
                                        {
                                            if (paramLocal["move"] == "close")
                                            {
                                                if (session.User.HavePermision(".tickets.close"))
                                                {
                                                    task.Closed = true;
                                                    task.SetAgree(session.User, paramLocal["aproove"] == "1" ? true : false, "");
                                                    SendEncryptedNLog(Client, Ser, session, "res=accept");
                                                }
                                                else
                                                {
                                                    SendEncryptedNLog(Client, Ser, session, "{1}");
                                                }
                                            }
                                            else
                                            {
                                                decimal vl = 0;
                                                decimal.TryParse(paramLocal["pr"], out vl);
                                                if ((double)vl != task.Priority)
                                                {
                                                    if (task.Priority == 0)
                                                    {
                                                        if (session.User.HavePermision(".tickets.priority.set"))
                                                        {
                                                            task.TaskUpdates.Add(new TaskUpdates(session.User.ToString() + " установил приоритет " + (double)vl));
                                                            task.Priority = (double)vl;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        vl = Math.Max(0.1m, vl);
                                                        if (session.User.HavePermision(".tickets.priority.edit"))
                                                        {
                                                            task.TaskUpdates.Add(new TaskUpdates(session.User.ToString() + " изменил приоритет с " + task.Priority + " на " + (double)vl));
                                                            task.Priority = (double)vl;
                                                        }
                                                    }
                                                }
                                                if (task.SetAgree(session.User, paramLocal["aproove"] == "1" ? true : false, ""))
                                                {
                                                    SendEncryptedNLog(Client, Ser, session, "res=accept");
                                                }
                                                else
                                                {
                                                    SendEncryptedNLog(Client, Ser, session, "res=denied&message=Все согласования проставлены, или вы не имеете доступа к задаче, или согласование направленно на другого человека");
                                                }
                                            }
                                        }
                                        else
                                        {
                                            session.User.CoolDownExpire = DateTime.Now.AddMinutes(1);
                                        }
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                    }
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                            }
                        }
                        //Добавить согласование
                        else if (paramLocal["com"] == "addagree")
                        {
                            if (paramLocal.ContainsKey("id") & paramLocal.ContainsKey("stage"))
                            {
                                TicketTask task;
                                if (session.User.HavePermision(".Tickets.ViewDeleted"))
                                    task = TicketTask.GetById(null, int.Parse(paramLocal["id"]), true);
                                else
                                    task = TicketTask.GetById(null, int.Parse(paramLocal["id"]), false);
                                if (task == null)
                                {
                                    SendEncryptedNLog(Client, Ser, session, "res=denied&message=Задача не найдена");
                                }
                                else
                                {
                                    if (session.User.HavePermision(".Agreements.Add"))
                                    {
                                        TaskStage taskStage = TaskStage.GetByName(Form1.Context, paramLocal["stage"], true);
                                        if (taskStage != null)
                                        {
                                            if (task.CheckSpaceToAddAgree(taskStage))
                                            {
                                                var newagree = new Agreement(taskStage);
                                                task.TaskUpdates.Add(new TaskUpdates(session.User.ToString() + " добавил согласование на этап " + taskStage.Name));
                                                newagree.Sender = session.User;
                                                task.Agreements.Add(newagree);
                                                if (taskStage.AutoPick)
                                                {
                                                    var user = taskStage.GetUserWithLowestSLAsum();
                                                    user.SLALast += taskStage.SLAminute;
                                                    newagree.Visor = user;
                                                }
                                            }
                                            else
                                            {
                                                SendEncryptedNLog(Client, Ser, session, "Отсутствует этап " + paramLocal["stage"] + " для которого еще не запрошенно согласование");
                                            }
                                        }
                                        else
                                        {
                                            SendEncryptedNLog(Client, Ser, session, "Этап " + paramLocal["stage"] + " не найден в системе");
                                        }
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                    }
                                    SendEncryptedNLog(Client, Ser, session, "res=accept");
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                            }
                        }
                        else if (paramLocal["com"] == "getstages")
                        {
                            if (session.User.HaveTreePermision(".stages."))
                            {
                                TaskStage[] stages = TaskStage.SearchByText(Form1.Context, "", session.User.HavePermision(".stages.ViewDeleted"));
                                string res = "res=accept&";
                                for (int i = 0; i < stages.Length; i++)
                                {
                                    res += "id=" + stages[i].Id + "&";
                                    res += "nm=" + stages[i].Name + "&";
                                    res += "ds=" + stages[i].Description + "&";
                                    res += "sla=" + stages[i].SLAminute + "&";
                                    res += "isd=" + (stages[i].Deleted ? 1 : 0).ToString() + "&";
                                    res += "ap=" + (stages[i].AutoPick ? 1 : 0).ToString() + "&";
                                    res += "rl=";
                                    for (int j = 0; j < stages[i].Roles.Count; j++)
                                    {
                                        res += stages[i].Roles[j].Name + ",";
                                    }
                                    res = res.Trim(',');
                                    res += "&";
                                }
                                res = res.Trim('&').Trim(',');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        else if (paramLocal["com"] == "setstage")
                        {
                            if (paramLocal.ContainsKey("id"))
                            {

                                TaskStage stage = TaskStage.GetById(paramLocal["id"]);
                                if (stage == null)
                                {
                                    SendEncryptedNLog(Client, Ser, session, "res=denied&message=Этап не найден");
                                    return;
                                }
                                if (paramLocal.ContainsKey("nm"))
                                    if (session.User.HavePermision(".stages.name.edit"))
                                        stage.Name = paramLocal["nm"];
                                if (paramLocal.ContainsKey("ds"))
                                    if (session.User.HavePermision(".stages.description.edit"))
                                        stage.Description = paramLocal["ds"];
                                if (paramLocal.ContainsKey("sla"))
                                    if (session.User.HavePermision(".stages.sla.edit"))
                                        if (double.TryParse(paramLocal["sla"], out double sla))
                                            stage.SLAminute = sla;

                                if (paramLocal.ContainsKey("isd"))
                                    if (session.User.HavePermision(".stages.delete"))
                                        stage.Deleted = paramLocal["isd"] == "1" ? true : false;
                                if (paramLocal.ContainsKey("ap"))
                                    if (session.User.HavePermision(".stages.autopick.edit"))
                                        stage.AutoPick = paramLocal["ap"] == "1" ? true : false;
                                if (paramLocal.ContainsKey("rla"))
                                    if (session.User.HavePermision(".stages.roles.add"))
                                    {
                                        string[] roles = paramLocal["rla"].Split(',');
                                        for (int i = 0; i < roles.Length; i++)
                                        {
                                            var role = Role.GetByName(null, roles[i], session.User.HavePermision(".roles.viewdeleted"));
                                            if (role != null)
                                                if (!stage.Roles.Contains(role))
                                                    stage.Roles.Add(role);
                                        }
                                    }
                                if (paramLocal.ContainsKey("rld"))
                                    if (session.User.HavePermision(".stages.roles.delete"))
                                    {
                                        string[] roles = paramLocal["rld"].Split(',');
                                        for (int i = 0; i < roles.Length; i++)
                                        {
                                            var role = Role.GetByName(null, roles[i], session.User.HavePermision(".roles.viewdeleted"));
                                            if (role != null)
                                                if (stage.Roles.Contains(role))
                                                    stage.Roles.Remove(role);
                                        }
                                    }

                                string res = "res=accept";
                                res += "&id=" + stage.Id;
                                res += "&nm=" + stage.Name;
                                res += "&ds=" + stage.Description;
                                res += "&sla=" + stage.SLAminute;
                                res += "&isd=" + (stage.Deleted ? 1 : 0).ToString();
                                res += "&ap=" + (stage.AutoPick ? 1 : 0).ToString();
                                res += "&rl=";
                                for (int j = 0; j < stage.Roles.Count; j++)
                                {
                                    res += stage.Roles[j].Name + ",";
                                }
                                res = res.Trim(',');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                        }
                        else if (paramLocal["com"] == "addstage")
                        {
                            if (paramLocal.ContainsKey("nm"))
                            {
                                if (session.User.HavePermision(".stages.add"))
                                {
                                    TaskStage stage = TaskStage.GetByName(null, paramLocal["nm"], true);
                                    if (stage == null)
                                    {
                                        stage = new TaskStage();
                                        stage.Name = paramLocal["nm"];
                                        string res = "res=accept";
                                        res += "&id=" + stage.Id;
                                        res += "&nm=" + stage.Name;
                                        res += "&ds=" + stage.Description;
                                        res += "&sla=" + stage.SLAminute;
                                        res += "&isd=" + (stage.Deleted ? 1 : 0).ToString();
                                        res += "&ap=" + (stage.AutoPick ? 1 : 0).ToString();
                                        res += "&rl=";
                                        for (int j = 0; j < stage.Roles.Count; j++)
                                        {
                                            res += stage.Roles[j].Name + ",";
                                        }
                                        res = res.Trim(',');
                                        SendEncryptedNLog(Client, Ser, session, res);
                                        return;
                                    }
                                    else
                                        SendEncryptedNLog(Client, Ser, session, "res=denied&message=Этап с таким именем уже существует");
                                }
                                else
                                    SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                            else
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                        }
                        else if (paramLocal["com"] == "savecomments")
                        {
                            if (paramLocal.ContainsKey("id") & paramLocal.ContainsKey("cm"))
                            {
                                TicketTask task = TicketTask.GetById(null, int.Parse(paramLocal["id"]), session.User.HavePermision(".Tickets.ViewDeleted"));
                                if (task == null)
                                {
                                    SendEncryptedNLog(Client, Ser, session, "res=denied&message=Задача не найдена");
                                }
                                else
                                {
                                    if (session.User.HavePermision(".Tickets.comments.edit"))
                                    {
                                        task.Comments = paramLocal["cm"];
                                        SendEncryptedNLog(Client, Ser, session, "res=accept");
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                    }
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                            }
                        }
                        else if (paramLocal["com"] == "addcomment")
                        {
                            if (paramLocal.ContainsKey("id") & paramLocal.ContainsKey("cm"))
                            {
                                TicketTask task = TicketTask.GetById(null, int.Parse(paramLocal["id"]), session.User.HavePermision(".Tickets.ViewDeleted"));
                                if (task == null)
                                {
                                    SendEncryptedNLog(Client, Ser, session, "res=denied&message=Задача не найдена");
                                }
                                else
                                {
                                    if (session.User.HavePermision(".Tickets.comments.add"))
                                    {
                                        if (task.Comments.EndsWith("\r\n"))
                                            task.Comments += paramLocal["cm"] + "\r\n";
                                        else
                                            task.Comments += "\r\n" + paramLocal["cm"] + "\r\n";
                                        SendEncryptedNLog(Client, Ser, session, "res=accept");
                                    }
                                    else
                                    {
                                        SendEncryptedNLog(Client, Ser, session, "{1}");
                                    }
                                }
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                            }
                        }
                        else if (paramLocal["com"] == "gettasktypes")
                        {
                            if (session.User.HaveTreePermision(".types.view"))
                            {
                                TaskType[] types = TaskType.SearchByText(Form1.Context, "", session.User.HavePermision(".types.ViewDeleted"));
                                string res = "res=accept&";
                                for (int i = 0; i < types.Length; i++)
                                {
                                    res += "id=" + types[i].Id + "&";
                                    res += "nm=" + types[i].Name + "&";
                                    res += "ds=" + types[i].Description + "&";
                                    res += "isd=" + (types[i].Deleted ? 1 : 0).ToString() + "&";
                                    res += "isdef=" + (types[i].isDefault ? 1 : 0).ToString() + "&";
                                    res += "st=";
                                    for (int j = 0; j < types[i].Stages.Count; j++)
                                    {
                                        res += types[i].Stages[j].Name + ",";
                                    }
                                    res = res.Trim(',');
                                    res += "&";
                                }
                                res = res.Trim('&').Trim(',');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                            {
                                SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                        }
                        else if (paramLocal["com"] == "settasktype")
                        {
                            if (paramLocal.ContainsKey("id"))
                            {
                                TaskType type = TaskType.GetById(paramLocal["id"]);
                                if (type == null)
                                {
                                    SendEncryptedNLog(Client, Ser, session, "res=denied&message=Тип не найден");
                                    return;
                                }
                                if (paramLocal.ContainsKey("nm"))
                                    if (session.User.HavePermision(".types.name.edit"))
                                        type.Name = paramLocal["nm"];
                                if (paramLocal.ContainsKey("ds"))
                                    if (session.User.HavePermision(".types.description.edit"))
                                        type.Description = paramLocal["ds"];

                                if (paramLocal.ContainsKey("isd"))
                                    if (session.User.HavePermision(".types.delete"))
                                        type.Deleted = paramLocal["isd"] == "1" ? true : false;
                                if (paramLocal.ContainsKey("isdef"))
                                    if (session.User.HavePermision(".types.isdefault.edit"))
                                    {
                                        type.isDefault = paramLocal["isdef"] == "1" ? true : false;
                                        if (type.isDefault)
                                        {
                                            foreach (var tt in TaskType.TaskTypes)
                                                tt.isDefault = false;
                                        }
                                    }
                                if (paramLocal.ContainsKey("sta"))
                                    if (session.User.HavePermision(".types.stages.add"))
                                    {
                                        string[] stages = paramLocal["sta"].Split(',');
                                        for (int i = 0; i < stages.Length; i++)
                                        {
                                            var stage = TaskStage.GetByName(null, stages[i], session.User.HavePermision(".stages.viewdeleted"));
                                            if (stage != null)
                                                if (!type.Stages.Contains(stage))
                                                    type.Stages.Add(stage);
                                        }
                                    }
                                if (paramLocal.ContainsKey("std"))
                                    if (session.User.HavePermision(".types.stages.delete"))
                                    {
                                        string[] stages = paramLocal["std"].Split(',');
                                        for (int i = 0; i < stages.Length; i++)
                                        {
                                            var stage = TaskStage.GetByName(null, stages[i], session.User.HavePermision(".stages.viewdeleted"));
                                            if (stage != null)
                                                if (type.Stages.Contains(stage))
                                                    type.Stages.Remove(stage);
                                        }
                                    }

                                string res = "res=accept";
                                res += "&id=" + type.Id;
                                res += "&nm=" + type.Name;
                                res += "&ds=" + type.Description;
                                res += "&isd=" + (type.Deleted ? 1 : 0).ToString();
                                res += "&isdef=" + (type.isDefault ? 1 : 0).ToString();
                                res += "&st=";
                                for (int j = 0; j < type.Stages.Count; j++)
                                {
                                    res += type.Stages[j].Name + ",";
                                }
                                res = res.Trim(',');
                                SendEncryptedNLog(Client, Ser, session, res);
                            }
                            else
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                        }
                        else if (paramLocal["com"] == "addtasktype")
                        {
                            if (paramLocal.ContainsKey("nm"))
                            {
                                if (session.User.HavePermision(".types.add"))
                                {
                                    TaskType type = TaskType.GetByName(null, paramLocal["nm"], true);
                                    if (type == null)
                                    {
                                        type = new TaskType();
                                        type.Name = paramLocal["nm"];
                                        string res = "res=accept";
                                        res += "&id=" + type.Id;
                                        res += "&nm=" + type.Name;
                                        res += "&ds=" + type.Description;
                                        res += "&isd=" + (type.Deleted ? 1 : 0).ToString();
                                        res += "&isdef=" + (type.isDefault ? 1 : 0).ToString();
                                        res += "&st=";
                                        for (int j = 0; j < type.Stages.Count; j++)
                                        {
                                            res += type.Stages[j].Name + ",";
                                        }
                                        res = res.Trim(',');
                                        SendEncryptedNLog(Client, Ser, session, res);
                                        return;
                                    }
                                    else
                                        SendEncryptedNLog(Client, Ser, session, "res=denied&message=Тип с таким именем уже существует");
                                }
                                else
                                    SendEncryptedNLog(Client, Ser, session, "{1}");
                            }
                            else
                                SendEncryptedNLog(Client, Ser, session, "{2}");
                        }
                        return;
                    }
                    else
                    {
                        ///Для выполнения этих команд нужно авторизоваться
                        string res = "com=needauth";
                        SendEncryptedNLog(Client, Ser, session, res);
                        return;
                    }
                }
            }
            else
            {
                SendError(Client, 500);
                return;
            }
        }
        /// <summary>
        /// 1-NoPermission;
        /// 2-require parametrs;
        /// 3-cooldown
        /// </summary>
        /// <param name="Client"></param>
        /// <param name="Ser"></param>
        /// <param name="session"></param>
        /// <param name="res"></param>
        private static void SendEncryptedNLog(TcpClient Client, ServerMain Ser, Session session, string res)
        {
            if (res == "{1}")
                res = "res=denied&message=" + Responsies[0];
            else if (res == "{2}")
                res = "res=denied&message=" + Responsies[1];
            else if (res == "{3}")
                res = "res=denied&message=" + Responsies[2].Replace(" & expiretimer&", DateTime.Now.Subtract(session.User.CoolDownExpire).TotalMinutes + "");
            byte[] msg;
            ConOut(Ser.synchronization, res.Length > 150 ? res.Remove(150) : res);
            msg = session.RSA.Encrypt(res);
            msg = RSACrypt.SetLength(msg);
            Client.GetStream().Write(msg, 0, msg.Length);
        }
        static string[] Responsies = new string[] { "У вас не хватает прав", "Не хватает обязательных параметров, обновите ПО", "На вашем аккаунте замечена подозрительная активность, \r\nвы сможете продолжить работу через: &expiretimer& мин." };

        static Dictionary<string, string> GetParams(string str)
        {
            Dictionary<string, string> param = new Dictionary<string, string>();
            string[] paramf = str.Split(new string[] { "&" }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < paramf.Length; i++)
            {
                int pos = paramf[i].IndexOf('=');
                if (pos >= 0)
                {
                    param.Add(paramf[i].Substring(0, pos), paramf[i].Substring(pos + 1));
                }
            }
            return param;
        }
        static byte[] GetResponse(TcpClient request)
        {
            List<byte> res = new List<byte>();
            byte[] buf = new byte[500];
            int length = -1;
            int count = 0;
            try
            {
                request.GetStream().ReadTimeout = 2000;
            A: count = request.GetStream().Read(buf, 0, buf.Length);
                res.AddRange(buf.Take(count).ToArray());
                if (count >= 4 & length == -1)
                    length = RSACrypt.GetLength(buf);
                if (count == buf.Length | length >= 0 ? res.Count < length : false)
                    goto A;
            }
            catch (Exception ex)
            {

            }
            if (length >= 4)
                res = res.Skip(4).ToList();
            return res.ToArray();
        }
        static string CreateLong(string[] args)
        {
            string CodeStr = 200.ToString() + " " + ((HttpStatusCode)200).ToString();
            string Html = "";
            for (int i = 0; i < args.Length; i++)
            {
                Html += args[i] + "&";
            }
            Html = Html.TrimEnd(new char[] { '&' });
            string Str = "HTTP/1.1 " + CodeStr + "\r\nContent-type: text/html\r\nContent-Length:" + Encoding.UTF8.GetByteCount(Html) + "\r\nRefresh:0\r\nConnection: Closed\r\n\r\n" + Html;
            //byte[] Buffer = Encoding.ASCII.GetBytes(Str);
            return Str;
        }
        static string CreateShort(string[] args)
        {
            string CodeStr = 200.ToString() + " " + ((HttpStatusCode)200).ToString();
            string Html = "";
            for (int i = 0; i < args.Length; i++)
            {
                Html += args[i] + "&";
            }
            Html = Html.TrimEnd(new char[] { '&' });
            string Str = Html;
            //byte[] Buffer = Encoding.ASCII.GetBytes(Str);
            return Str;
        }
        static Dictionary<string, string> GetBlocks(string str, out string clear)
        {
            int st = str.IndexOf("<blocks>");
            if (st >= 0)
            {
                int end = str.IndexOf("</blocks>", st);
                if (end >= 0)
                {
                    string sub = str.Substring(st, end - st + 9);
                    Dictionary<string, string> ot = new Dictionary<string, string>();
                    string[] fstr = sub.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
                    for (int i = 1; i < fstr.Length - 1; i++)
                    {
                        int fg = fstr[i].IndexOf('_');
                        if (fg >= 0)
                        {
                            ot.Add(fstr[i].Substring(0, fg), fstr[i].Substring(fg + 1));
                        }
                    }
                    clear = str.Remove(st, end - st + 9);
                    return ot;
                }
            }
            clear = str;
            return new Dictionary<string, string>();
        }

        static void SendError(TcpClient Client, int Code)
        {
            try
            {
                string CodeStr = Code.ToString() + " " + ((HttpStatusCode)Code).ToString();
                string Html = "<html><body><h1>" + CodeStr + "</h1></body></html>";
                string Str = "HTTP/1.1 " + CodeStr + "\nContent-type: text/html\nContent-Length:" + Html.Length.ToString() + "\n\n" + Html;
                byte[] Buffer = Encoding.ASCII.GetBytes(Str);
                Client.GetStream().Write(Buffer, 0, Buffer.Length);
                Client.Close();
            }
            catch
            {

            }
        }
        public static string Get(string url)
        {
            int st = Environment.TickCount;
            url = url.Replace(" ", "_");
            Uri ur = new Uri(url);
            //host = ur.Host;//url.Substring(0, url.IndexOf('/', url.IndexOf(':') + 3));
            //string target = ur.AbsolutePath;
            StringBuilder ot = new StringBuilder();
            TcpClient Client = new TcpClient();
            try
            {
                Client.Connect(ur.Host, 80);
                Client.ReceiveTimeout = 10000;
                Client.SendTimeout = 10000;
                NetworkStream tcpStream = Client.GetStream();
                byte[] sendBytes = Encoding.Default.GetBytes("GET " + ur.LocalPath + " HTTP/1.1\r\nHost: " + ur.Host + "\n\n");
                tcpStream.Write(sendBytes, 0, sendBytes.Length);
                byte[] bytes = new byte[Client.ReceiveBufferSize];
                int Count = 0;
                int startt = Environment.TickCount;
                int pausenum = 0;
                for (; Client.Connected;)
                {
                    Count = Client.GetStream().Read(bytes, 0, bytes.Length);
                    ot.Append(Encoding.Default.GetString(bytes, 0, Count));
                    if (ot.ToString().EndsWith("^"))
                        break;
                    if (Count == 0)
                    {
                        if (pausenum == 0)
                        {
                            System.Threading.Thread.Sleep(15);
                        }
                        else if (pausenum == 1)
                        {
                            System.Threading.Thread.Sleep(45);
                        }
                        else if (pausenum == 2)
                        {
                            System.Threading.Thread.Sleep(150);
                        }
                        else if (pausenum == 3)
                        {
                            System.Threading.Thread.Sleep(450);
                        }
                        else
                        {
                            break;
                        }
                        pausenum++;
                    }
                    else
                    {
                        pausenum = 0;
                    }
                    if (Environment.TickCount - startt >= 5000)
                    {
                        break;
                    }
                }
                Client.Close();
                string f = ot.ToString();
                return f;
            }
            catch (Exception ex)
            {
                Client.Client.Dispose();
                return "/err " + ex.Data;
            }
        }
        public static string Get_Def(string url)
        {
            int st = Environment.TickCount;
            url = url.Replace(" ", "_");
            Uri ur = new Uri(url);
            string host = ur.Host;
            string target = ur.AbsolutePath;
            try
            {
                System.Net.WebRequest req = System.Net.WebRequest.Create(url);
                System.Net.WebResponse resp = req.GetResponse();
                System.IO.Stream stream = resp.GetResponseStream();
                System.IO.StreamReader sr = new System.IO.StreamReader(stream);
                string Out = sr.ReadToEnd();
                sr.Close();
                return Out;
            }
            catch (Exception ex)
            {
                return "/err " + ex.Data;
            }
        }
        public static string Post(string url, string data)
        {
            int st = Environment.TickCount;
            url = url.Replace(" ", "_");
            Uri ur = new Uri(url);
            //host = ur.Host;//url.Substring(0, url.IndexOf('/', url.IndexOf(':') + 3));
            //string target = ur.AbsolutePath;
            StringBuilder ot = new StringBuilder();
            TcpClient Client = new TcpClient();
            try
            {
                Client.Connect(ur.Host, 80);
                Client.ReceiveTimeout = 2000;
                Client.SendTimeout = 2000;
                NetworkStream tcpStream = Client.GetStream();
                byte[] sendBytes = Encoding.Default.GetBytes("POST " + ur.LocalPath + " HTTP/1.1\r\nHost: " + ur.Host + "\r\nContent-Length: " + Encoding.Default.GetByteCount(data) + "\r\n\r\n" + data);
                tcpStream.Write(sendBytes, 0, sendBytes.Length);
                byte[] bytes = new byte[Client.ReceiveBufferSize];
                int Count = 0;
                int startt = Environment.TickCount;
                for (; Client.Connected;)
                {
                    Count = Client.GetStream().Read(bytes, 0, bytes.Length);
                    ot.Append(Encoding.Default.GetString(bytes, 0, Count));
                    if (ot.ToString().EndsWith("^"))
                        break;
                    System.Threading.Thread.Sleep(15);
                    if (Client.Available <= 0)
                    {
                        System.Threading.Thread.Sleep(100);
                    }
                    if (Client.Available <= 0)
                    {
                        break;
                    }
                    if (Environment.TickCount - startt >= 5000)
                    {
                        break;
                    }
                }
                Client.Close();
                string f = ot.ToString();
                return f;
            }
            catch (Exception ex)
            {
                Client.Client.Dispose();
                return "/err " + ex.Data;
            }
        }
        public static byte[] GetBin(string url)
        {
            int st = Environment.TickCount;
            url = url.Replace(" ", "_");
            Uri ur = new Uri(url);
            //host = ur.Host;//url.Substring(0, url.IndexOf('/', url.IndexOf(':') + 3));
            //string target = ur.AbsolutePath;
            //byte[] ot = new byte[100 * 1024];
            List<byte> ot = new List<byte>();
            int all = 0;
            int pausenum = 0;
            TcpClient Client = new TcpClient();
            try
            {
                int startt = Environment.TickCount;
                Client.Connect(ur.Host, 443);
                Client.ReceiveTimeout = 10000;
                Client.SendTimeout = 10000;
                NetworkStream tcpStream = Client.GetStream();
                byte[] sendBytes = Encoding.UTF8.GetBytes("GET " + ur.AbsoluteUri + " HTTP/1.1\r\nHost: " + ur.Host);
                tcpStream.Write(sendBytes, 0, sendBytes.Length);
                using (Stream stream = Client.GetStream())
                {
                    for (; Client.Connected;)
                    {
                        System.Threading.Thread.Sleep(500);
                        byte[] buf = new byte[100 * 1024];
                        int Count = Client.GetStream().Read(buf, 0, buf.Length);
                        byte[] buf2 = new byte[Count];
                        for (int i = 0; i < Count; i++)
                            buf2[i] = buf[i];
                        ot.AddRange(buf2);
                        if (Count == 0)
                        {
                            if (pausenum == 0)
                            {
                                System.Threading.Thread.Sleep(15);
                            }
                            else if (pausenum == 1)
                            {
                                System.Threading.Thread.Sleep(45);
                            }
                            else if (pausenum == 2)
                            {
                                System.Threading.Thread.Sleep(150);
                            }
                            else if (pausenum == 3)
                            {
                                System.Threading.Thread.Sleep(450);
                            }
                            else
                            {
                                break;
                            }
                            pausenum++;
                        }
                        else
                        {
                            pausenum = 0;
                        }
                        if (Environment.TickCount - startt >= 5000)
                        {
                            break;
                        }
                    }
                }
                Client.Close();
                Console.WriteLine("Date length:" + ot.Count);
                byte[] fn = new byte[ot.Count];
                for (int i = 0; i < fn.Length; i++)
                    fn[i] = ot[i];
                return fn;
            }
            catch (Exception ex)
            {
                Client.Client.Dispose();
                return new byte[] { };
            }
        }
    }
}
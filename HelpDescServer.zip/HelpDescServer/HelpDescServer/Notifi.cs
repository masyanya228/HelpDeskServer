﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class Notifi
    {
        public Notifi(NotifiType type, DateTime creationTime)
        {
            Type = type;
            CreationTime = creationTime;
        }

        public int Id { get; set; }
        public NotifiType Type { get; set; }
        public DateTime CreationTime { get; set; }
        public object Tag { get; set; }

        public enum NotifiType
        {
            NewTask,
            YourStage,
            NewCommentOnYorRequest,
            NewStageOnYourRequest,
            NewRole
        }
    }
}
﻿namespace HelpDescServer
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class CodeFirstContext : DbContext
    {
        // Контекст настроен для использования строки подключения "Model2" из файла конфигурации  
        // приложения (App.config или Web.config). По умолчанию эта строка подключения указывает на базу данных 
        // "HelpDescServer.Model2" в экземпляре LocalDb. 
        // 
        // Если требуется выбрать другую базу данных или поставщик базы данных, измените строку подключения "Model2" 
        // в файле конфигурации приложения.
        public CodeFirstContext()
            : base("name=Model2")
        {
        }

        // Добавьте DbSet для каждого типа сущности, который требуется включить в модель. Дополнительные сведения 
        // о настройке и использовании модели Code First см. в статье http://go.microsoft.com/fwlink/?LinkId=390109.
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<TicketTask> TicketTasks { get; set; }
        public virtual DbSet<Permision> Permisions { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<TaskType> TaskTypes { get; set; }
        public virtual DbSet<TaskStage> TaskStages { get; set; }
        public virtual DbSet<Agreement> Agreements { get; set; }
        public virtual DbSet<TaskUpdates> TaskUpdates { get; set; }
        public virtual DbSet<Notifi> Notifis { get; set; }
    }

    //public class MyEntity
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //}
}
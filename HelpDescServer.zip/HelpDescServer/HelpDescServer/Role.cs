﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class Role
    {
        public static List<Role> Roles = new List<Role>();
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public bool Deleted { get; set; } = false;
        public bool isDefault { get; set; } = false;
        public bool isLeaderDefaultRole { get; set; } = false;
        public List<Permision> Permisions { get => permisions; set => permisions = value; }

        //public virtual List<string> PermisionsKeys { get; set; }
        private List<Permision> permisions = new List<Permision>();

        public Role()
        {
            Id = getId();
            Roles.Add(this);
        }
        public int getId()
        {
            return Roles.Count > 0 ? Roles[Roles.Count - 1].Id + 1 : 0;
        }
        public override string ToString()
        {
            return Name ?? "Без имени";
        }

        public static void Creation(CodeFirstContext context)
        {
            Role role = new Role()
            {
                Name = "Super.Admin"
            };
            role.Permisions.AddRange(Permision.GetTreeByName(context, "."));
            //context.Roles.Add(role);

            role = new Role()
            {
                Name = "Default"
            };
            //context.Roles.Add(role);

            role = new Role()
            {
                Name = "Priority Manager"
            };
            role.Permisions.AddRange(Permision.GetTreeByName(context, ".tickets.priority"));
            //context.Roles.Add(role);

            role = new Role()
            {
                Name = "Руководитель"
            };
            //context.Roles.Add(role);

            role = new Role()
            {
                Name = "Бухгалтерия"
            };
            //context.Roles.Add(role);

            role = new Role()
            {
                Name = "Специалист"
            };
            //context.Roles.Add(role);
            return;
            for (int i = 0; i < 100; i++)
            {
                role = new Role()
                {
                    Name = "PayLoadTest" + i,
                    Description = Cryptographi.GetRandom(100),
                    Deleted = Char.IsDigit(Cryptographi.GetRandom(1)[0])
                };
                //context.Roles.Add(role);
            }
        }
        public User GetUserWithLowestSLAsum()
        {
            var users = GetUsersToRole();
            if (users.Count() != 0)
            {
                for (int i = 0; i < users.Length; i++)
                {
                    users[i].SLALast = users[i].GetSLAsum();
                }
                users = users.OrderBy(x => x.SLALast).ToArray();
                return users.ToArray()[0];
            }
            else
            {
                return null;
            }
        }
        public User[] GetUsersToRole()
        {
            List<User> result = new List<User>();
            foreach (User user in User.Users)
            {
                bool CanToAll = true;
                if (!user.CanDoRole(this))
                {
                    CanToAll = false;
                    break;
                }
                if (CanToAll)
                    result.Add(user);
            }
            return result.ToArray();
        }

        public static Role GetByName(CodeFirstContext context, string name = "Default", bool withdel = false)
        {
            foreach (Role role in Roles)
            {
                if (!role.Deleted | withdel)
                    if (role.Name.ToLower() == name.ToLower())
                        return role;
            }
            return null;
        }

        public static Role GetDefault()
        {
            foreach (Role role in Roles)
            {
                if (!role.Deleted)
                    if (role.isDefault)
                        return role;
            }
            return null;
        }

        public static Role GetDefaultLeaderRole()
        {
            foreach (Role role in Roles)
            {
                if (!role.Deleted)
                    if (role.isLeaderDefaultRole)
                        return role;
            }
            return null;
        }

        public static Role[] GetAll(CodeFirstContext context, bool withdel = false)
        {
            List<Role> roles = new List<Role>();
            foreach (Role role in Roles)
            {
                if (!role.Deleted | withdel)
                    roles.Add(role);
            }
            return roles.ToArray();
        }
        public static Role[] GetAllWithOutPermisions(CodeFirstContext context)
        {
            List<Role> roles = new List<Role>();
            foreach (Role role in Roles)
            {
                if (!role.Deleted)
                    if (role.Permisions.Count == 0)
                        roles.Add(role);
            }
            return roles.ToArray();
        }

        public Permision[] GetAllPermisions()
        {
            return Permisions.ToArray();
        }
        public static Role[] SearchByText(CodeFirstContext context, string text, bool withdel = false)
        {
            var cachres = SearchCach.GetRes(text, typeof(Role), new TimeSpan(0, 0, 30));
            if (cachres == null)
            {
                List<Result> results = new List<Result>();
                List<Role> roles = new List<Role>();
                foreach (Role role in Roles)
                {
                    if (!role.Deleted | withdel)
                    {
                        if (text != "")
                        {
                            string a = role.Id + "/" + role.Name + "/" + role.Description + "/" + role.GetAllPermisions().ArrayToString('/');
                            double res = a.CompareString(text);
                            if (res > 0)
                            {
                                results.Add(new Result() { item = role, rank = res });
                            }
                        }
                        else
                        {
                            roles.Add(role);
                        }
                    }
                }
                if (roles.Count == 0)
                {
                    if (results.Count > 0)
                        results = results.OrderByDescending(x => x.rank).ToList();
                    for (int i = 0; i < results.Count; i++)
                    {
                        roles.Add(results[i].item as Role);
                    }
                }
                SearchCach.SetRes(text, typeof(Role), roles.ToArray());
                return roles.ToArray();
            }
            else
            {
                return (cachres as Role[]);
            }
        }
    }
}
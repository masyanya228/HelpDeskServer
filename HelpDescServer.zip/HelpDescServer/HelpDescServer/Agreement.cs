﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDescServer
{
    public class Agreement
    {
        private DateTime dateOfReq = DateTime.Now;
        private DateTime dateOfApprove = DateTime.Now;

        public int Id { get; set; }
        //public TicketTask Link { get; set; }
        public TaskStage TaskStage { get; set; }
        public User Sender { get; set; }
        public User Visor { get; set; }
        public bool Checked { get; set; } = false;
        public bool Aproove { get; set; } = false;
        public DateTime DateOfReq { get => dateOfReq; set => dateOfReq = value; }
        public DateTime DateOfApprove { get => dateOfApprove; set => dateOfApprove = value; }

        public Agreement(TaskStage taskStage)
        {
            //Link = link;
            TaskStage = taskStage;
            Checked = false;
            Aproove = false;
            DateOfReq = DateTime.Now;
        }

        public override string ToString()
        {
            return TaskStage.ToString() ?? "Без имени" + " - " + (Visor != null ? Visor.ToString() : "Неназначено") + (Checked ? " - " + (Aproove ? "Согласованно" : "Отказ") : "");
        }

        public double GetLeftSla()
        {
            return DateTime.Now.Subtract(DateOfReq).TotalMinutes;
        }
    }
}